import { pgTable, text, serial, timestamp, boolean, numeric, bigint } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const imperionUsersTable = pgTable("imperion_users", {
  uid: text("uid").primaryKey(),
  username: text("username").notNull().unique(),
  mobile: text("mobile"),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  referralCode: text("referral_code").unique(),
  referredBy: text("referred_by"),
  ipAddress: text("ip_address"),
  isActivated: boolean("is_activated").notNull().default(false),
  taskBalance: numeric("task_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  referralBalance: numeric("referral_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  depositBalance: numeric("deposit_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  dailyClaimBalance: numeric("daily_claim_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  hasClaimedAirtimeData: boolean("has_claimed_airtime_data").notNull().default(false),
  lastDailyClaim: bigint("last_daily_claim", { mode: "number" }),
  liteBalance: numeric("lite_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  liteActivatedAt: bigint("lite_activated_at", { mode: "number" }),
  liteLastAccrual: bigint("lite_last_accrual", { mode: "number" }),
  basicBalance: numeric("basic_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  basicActivatedAt: bigint("basic_activated_at", { mode: "number" }),
  basicLastAccrual: bigint("basic_last_accrual", { mode: "number" }),
  standardBalance: numeric("standard_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  standardActivatedAt: bigint("standard_activated_at", { mode: "number" }),
  standardLastAccrual: bigint("standard_last_accrual", { mode: "number" }),
  premiumBalance: numeric("premium_balance", { precision: 15, scale: 2 }).notNull().default("0"),
  premiumActivatedAt: bigint("premium_activated_at", { mode: "number" }),
  premiumLastAccrual: bigint("premium_last_accrual", { mode: "number" }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionDepositsTable = pgTable("imperion_deposits", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull(),
  username: text("username"),
  email: text("email"),
  amount: numeric("amount", { precision: 15, scale: 2 }).notNull(),
  receiptImage: text("receipt_image"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionWithdrawalsTable = pgTable("imperion_withdrawals", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull(),
  username: text("username"),
  email: text("email"),
  amount: numeric("amount", { precision: 15, scale: 2 }).notNull(),
  type: text("type").notNull(),
  bankName: text("bank_name"),
  accountNumber: text("account_number"),
  accountHolder: text("account_holder"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionTasksTable = pgTable("imperion_tasks", {
  id: serial("id").primaryKey(),
  category: text("category").notNull(),
  numberOfPeople: numeric("number_of_people").notNull().default("0"),
  price: numeric("price", { precision: 15, scale: 2 }).notNull(),
  link: text("link"),
  description: text("description"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionTaskSubmissionsTable = pgTable("imperion_task_submissions", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull(),
  username: text("username"),
  taskId: text("task_id"),
  taskTitle: text("task_title"),
  taskAmount: numeric("task_amount", { precision: 15, scale: 2 }).notNull().default("0"),
  proofImage: text("proof_image"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionReviewsTable = pgTable("imperion_reviews", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  text: text("text").notNull(),
  rating: numeric("rating").notNull().default("5"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionPortalStatusTable = pgTable("imperion_portal_status", {
  id: serial("id").primaryKey(),
  referralClosed: boolean("referral_closed").notNull().default(false),
  taskClosed: boolean("task_closed").notNull().default(false),
  dailyClosed: boolean("daily_closed").notNull().default(false),
  investmentClosed: boolean("investment_closed").notNull().default(false),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow(),
});

export const imperionAirtimeOrdersTable = pgTable("imperion_airtime_orders", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull(),
  username: text("username"),
  email: text("email"),
  mobile: text("mobile"),
  network: text("network"),
  type: text("type"),
  amount: numeric("amount", { precision: 15, scale: 2 }).notNull().default("200"),
  status: text("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertImperionUserSchema = createInsertSchema(imperionUsersTable).omit({ createdAt: true });
export type InsertImperionUser = z.infer<typeof insertImperionUserSchema>;
export type ImperionUser = typeof imperionUsersTable.$inferSelect;
