import { Router } from "express";
import { db } from "@workspace/db";
import {
  imperionUsersTable,
  imperionDepositsTable,
  imperionWithdrawalsTable,
  imperionTasksTable,
  imperionTaskSubmissionsTable,
  imperionReviewsTable,
  imperionPortalStatusTable,
  imperionAirtimeOrdersTable,
} from "@workspace/db";
import { eq, and, desc } from "drizzle-orm";

const router = Router();

const ADMIN_PASSCODE = "2011";

function requireAdmin(req: any, res: any, next: any) {
  const code = req.headers["x-admin-passcode"] || req.body?.adminPasscode;
  if (code !== ADMIN_PASSCODE) {
    res.status(401).json({ error: "Unauthorized" });
    return;
  }
  next();
}

function toUser(row: any) {
  if (!row) return null;
  return {
    uid: row.uid,
    username: row.username,
    mobile: row.mobile ?? "",
    email: row.email,
    passwordHash: row.passwordHash,
    referralCode: row.referralCode ?? "",
    referredBy: row.referredBy ?? "",
    ipAddress: row.ipAddress ?? "",
    isActivated: row.isActivated ?? false,
    taskBalance: parseFloat(row.taskBalance ?? "0"),
    referralBalance: parseFloat(row.referralBalance ?? "0"),
    depositBalance: parseFloat(row.depositBalance ?? "0"),
    dailyClaimBalance: parseFloat(row.dailyClaimBalance ?? "0"),
    hasClaimedAirtimeData: row.hasClaimedAirtimeData ?? false,
    lastDailyClaim: row.lastDailyClaim ?? null,
    liteBalance: parseFloat(row.liteBalance ?? "0"),
    liteActivatedAt: row.liteActivatedAt ?? null,
    liteLastAccrual: row.liteLastAccrual ?? null,
    basicBalance: parseFloat(row.basicBalance ?? "0"),
    basicActivatedAt: row.basicActivatedAt ?? null,
    basicLastAccrual: row.basicLastAccrual ?? null,
    standardBalance: parseFloat(row.standardBalance ?? "0"),
    standardActivatedAt: row.standardActivatedAt ?? null,
    standardLastAccrual: row.standardLastAccrual ?? null,
    premiumBalance: parseFloat(row.premiumBalance ?? "0"),
    premiumActivatedAt: row.premiumActivatedAt ?? null,
    premiumLastAccrual: row.premiumLastAccrual ?? null,
    createdAt: row.createdAt,
  };
}

// ─── Auth ──────────────────────────────────────────────────────────────────

router.post("/signup", async (req, res) => {
  try {
    const { uid, username, mobile, email, passwordHash, referralCode, referredBy, ipAddress } = req.body;
    if (!uid || !username || !email || !passwordHash) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }

    // Check username uniqueness
    const existingUsername = await db.select({ uid: imperionUsersTable.uid })
      .from(imperionUsersTable)
      .where(eq(imperionUsersTable.username, username))
      .limit(1);
    if (existingUsername.length > 0) {
      res.status(409).json({ error: "Username already taken. Please choose another." });
      return;
    }

    // Check email uniqueness
    const existingEmail = await db.select({ uid: imperionUsersTable.uid })
      .from(imperionUsersTable)
      .where(eq(imperionUsersTable.email, email))
      .limit(1);
    if (existingEmail.length > 0) {
      res.status(409).json({ error: "This email is already registered. Please login instead." });
      return;
    }

    // Check IP uniqueness (skip if unknown)
    if (ipAddress && ipAddress !== "unknown") {
      const existingIp = await db.select({ uid: imperionUsersTable.uid })
        .from(imperionUsersTable)
        .where(eq(imperionUsersTable.ipAddress, ipAddress))
        .limit(1);
      if (existingIp.length > 0) {
        res.status(409).json({ error: "An account already exists from your device/network." });
        return;
      }
    }

    const [inserted] = await db.insert(imperionUsersTable).values({
      uid,
      username,
      mobile: mobile ?? "",
      email,
      passwordHash,
      referralCode,
      referredBy: referredBy ?? "",
      ipAddress: ipAddress ?? "",
      isActivated: false,
      taskBalance: "0",
      referralBalance: "0",
      depositBalance: "0",
      dailyClaimBalance: "0",
      hasClaimedAirtimeData: false,
    }).returning();

    res.json({ user: toUser(inserted) });
  } catch (err: any) {
    req.log.error(err, "signup error");
    res.status(500).json({ error: "Signup failed. Please try again." });
  }
});

router.post("/login", async (req, res) => {
  try {
    const { email, passwordHash } = req.body;
    if (!email || !passwordHash) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const rows = await db.select().from(imperionUsersTable)
      .where(eq(imperionUsersTable.email, email))
      .limit(1);
    if (rows.length === 0) {
      res.status(404).json({ error: "No account found with these details. Please check your email and try again." });
      return;
    }
    const user = rows[0];
    if (user.passwordHash !== passwordHash) {
      res.status(401).json({ error: "Incorrect password. Please try again." });
      return;
    }
    res.json({ user: toUser(user) });
  } catch (err: any) {
    req.log.error(err, "login error");
    res.status(500).json({ error: "Login failed. Please try again." });
  }
});

// ─── Users ─────────────────────────────────────────────────────────────────

router.get("/user/:uid", async (req, res) => {
  try {
    const rows = await db.select().from(imperionUsersTable)
      .where(eq(imperionUsersTable.uid, req.params.uid))
      .limit(1);
    if (rows.length === 0) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json({ user: toUser(rows[0]) });
  } catch (err: any) {
    req.log.error(err, "get user error");
    res.status(500).json({ error: "Failed to get user" });
  }
});

router.patch("/user/:uid", async (req, res) => {
  try {
    const updates = { ...req.body };
    delete updates.uid;
    delete updates.email;
    delete updates.passwordHash;
    delete updates.referralCode;
    delete updates.ipAddress;
    delete updates.createdAt;

    // Map camelCase → snake_case column names handled by drizzle
    const dbUpdates: any = {};
    const fieldMap: Record<string, string> = {
      taskBalance: "taskBalance",
      referralBalance: "referralBalance",
      depositBalance: "depositBalance",
      dailyClaimBalance: "dailyClaimBalance",
      hasClaimedAirtimeData: "hasClaimedAirtimeData",
      lastDailyClaim: "lastDailyClaim",
      isActivated: "isActivated",
      username: "username",
      mobile: "mobile",
      liteBalance: "liteBalance",
      liteActivatedAt: "liteActivatedAt",
      liteLastAccrual: "liteLastAccrual",
      basicBalance: "basicBalance",
      basicActivatedAt: "basicActivatedAt",
      basicLastAccrual: "basicLastAccrual",
      standardBalance: "standardBalance",
      standardActivatedAt: "standardActivatedAt",
      standardLastAccrual: "standardLastAccrual",
      premiumBalance: "premiumBalance",
      premiumActivatedAt: "premiumActivatedAt",
      premiumLastAccrual: "premiumLastAccrual",
    };
    for (const [key, col] of Object.entries(fieldMap)) {
      if (key in updates) {
        dbUpdates[col] = updates[key];
      }
    }
    if (Object.keys(dbUpdates).length === 0) {
      res.status(400).json({ error: "No valid fields to update" });
      return;
    }

    const [updated] = await db.update(imperionUsersTable)
      .set(dbUpdates)
      .where(eq(imperionUsersTable.uid, req.params.uid))
      .returning();
    if (!updated) {
      res.status(404).json({ error: "User not found" });
      return;
    }
    res.json({ user: toUser(updated) });
  } catch (err: any) {
    req.log.error(err, "update user error");
    res.status(500).json({ error: "Failed to update user" });
  }
});

// Look up user by referral code
router.get("/user-by-referral/:code", async (req, res) => {
  try {
    const rows = await db.select({ uid: imperionUsersTable.uid })
      .from(imperionUsersTable)
      .where(eq(imperionUsersTable.referralCode, req.params.code))
      .limit(1);
    if (rows.length === 0) {
      res.status(404).json({ error: "Referral code not found" });
      return;
    }
    res.json({ uid: rows[0].uid });
  } catch (err: any) {
    req.log.error(err, "lookup referral error");
    res.status(500).json({ error: "Failed to lookup referral" });
  }
});

// Get referred users (by referrer uid)
router.get("/referrals/:uid", async (req, res) => {
  try {
    const rows = await db.select({
      uid: imperionUsersTable.uid,
      username: imperionUsersTable.username,
      isActivated: imperionUsersTable.isActivated,
      depositBalance: imperionUsersTable.depositBalance,
    }).from(imperionUsersTable)
      .where(eq(imperionUsersTable.referredBy, req.params.uid));
    res.json({ referrals: rows.map(r => ({ ...r, depositBalance: parseFloat(r.depositBalance ?? "0") })) });
  } catch (err: any) {
    req.log.error(err, "get referrals error");
    res.status(500).json({ error: "Failed to get referrals" });
  }
});

// ─── Deposits ──────────────────────────────────────────────────────────────

router.post("/deposits", async (req, res) => {
  try {
    const { uid, username, email, amount, receiptImage } = req.body;
    if (!uid || !amount) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const [inserted] = await db.insert(imperionDepositsTable).values({
      uid,
      username,
      email,
      amount: String(amount),
      receiptImage,
      status: "pending",
    }).returning();
    res.json({ deposit: { ...inserted, amount: parseFloat(inserted.amount) } });
  } catch (err: any) {
    req.log.error(err, "create deposit error");
    res.status(500).json({ error: "Failed to submit deposit" });
  }
});

router.get("/deposits/user/:uid", async (req, res) => {
  try {
    const rows = await db.select({
      id: imperionDepositsTable.id,
      uid: imperionDepositsTable.uid,
      username: imperionDepositsTable.username,
      amount: imperionDepositsTable.amount,
      status: imperionDepositsTable.status,
      createdAt: imperionDepositsTable.createdAt,
    }).from(imperionDepositsTable)
      .where(eq(imperionDepositsTable.uid, req.params.uid))
      .orderBy(desc(imperionDepositsTable.createdAt));
    res.json({ deposits: rows.map(d => ({ ...d, amount: parseFloat(d.amount) })) });
  } catch (err: any) {
    req.log.error(err, "get user deposits error");
    res.status(500).json({ error: "Failed to get deposits" });
  }
});

// Admin: get all deposits
router.get("/admin/deposits", requireAdmin, async (req, res) => {
  try {
    const rows = await db.select().from(imperionDepositsTable)
      .orderBy(desc(imperionDepositsTable.createdAt));
    res.json({ deposits: rows.map(d => ({ ...d, amount: parseFloat(d.amount) })) });
  } catch (err: any) {
    req.log.error(err, "admin get deposits error");
    res.status(500).json({ error: "Failed to get deposits" });
  }
});

// Admin: approve deposit
router.post("/admin/deposits/:id/approve", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [deposit] = await db.select().from(imperionDepositsTable).where(eq(imperionDepositsTable.id, id)).limit(1);
    if (!deposit) { res.status(404).json({ error: "Deposit not found" }); return; }

    await db.update(imperionDepositsTable).set({ status: "approved" }).where(eq(imperionDepositsTable.id, id));

    // Credit user's deposit balance
    const [user] = await db.select().from(imperionUsersTable).where(eq(imperionUsersTable.uid, deposit.uid)).limit(1);
    if (user) {
      const newDepositBal = parseFloat(user.depositBalance ?? "0") + parseFloat(deposit.amount);

      // Check if this is user's first approved deposit for referral commission
      if (user.referredBy) {
        const prevApproved = await db.select({ id: imperionDepositsTable.id })
          .from(imperionDepositsTable)
          .where(and(eq(imperionDepositsTable.uid, deposit.uid), eq(imperionDepositsTable.status, "approved")))
          .limit(1);
        if (prevApproved.length === 0) {
          // First approved deposit — give 10% referral commission
          const [referrer] = await db.select().from(imperionUsersTable)
            .where(eq(imperionUsersTable.uid, user.referredBy)).limit(1);
          if (referrer) {
            const commission = parseFloat(deposit.amount) * 0.1;
            await db.update(imperionUsersTable)
              .set({ referralBalance: String(parseFloat(referrer.referralBalance ?? "0") + commission) })
              .where(eq(imperionUsersTable.uid, referrer.uid));
          }
        }
      }

      await db.update(imperionUsersTable)
        .set({ depositBalance: String(newDepositBal) })
        .where(eq(imperionUsersTable.uid, deposit.uid));
    }

    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "approve deposit error");
    res.status(500).json({ error: "Failed to approve deposit" });
  }
});

// Admin: decline deposit
router.post("/admin/deposits/:id/decline", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.update(imperionDepositsTable).set({ status: "declined" }).where(eq(imperionDepositsTable.id, id));
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "decline deposit error");
    res.status(500).json({ error: "Failed to decline deposit" });
  }
});

// ─── Withdrawals ────────────────────────────────────────────────────────────

router.post("/withdrawals", async (req, res) => {
  try {
    const { uid, username, email, amount, type, bankName, accountNumber, accountHolder } = req.body;
    if (!uid || !amount || !type) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const [inserted] = await db.insert(imperionWithdrawalsTable).values({
      uid, username, email,
      amount: String(amount),
      type, bankName, accountNumber, accountHolder,
      status: "pending",
    }).returning();
    res.json({ withdrawal: { ...inserted, amount: parseFloat(inserted.amount) } });
  } catch (err: any) {
    req.log.error(err, "create withdrawal error");
    res.status(500).json({ error: "Failed to submit withdrawal" });
  }
});

router.get("/withdrawals/user/:uid", async (req, res) => {
  try {
    const rows = await db.select().from(imperionWithdrawalsTable)
      .where(eq(imperionWithdrawalsTable.uid, req.params.uid))
      .orderBy(desc(imperionWithdrawalsTable.createdAt));
    res.json({ withdrawals: rows.map(w => ({ ...w, amount: parseFloat(w.amount) })) });
  } catch (err: any) {
    req.log.error(err, "get user withdrawals error");
    res.status(500).json({ error: "Failed to get withdrawals" });
  }
});

// Admin: get all withdrawals
router.get("/admin/withdrawals", requireAdmin, async (req, res) => {
  try {
    const rows = await db.select().from(imperionWithdrawalsTable)
      .orderBy(desc(imperionWithdrawalsTable.createdAt));
    res.json({ withdrawals: rows.map(w => ({ ...w, amount: parseFloat(w.amount) })) });
  } catch (err: any) {
    req.log.error(err, "admin get withdrawals error");
    res.status(500).json({ error: "Failed to get withdrawals" });
  }
});

// Admin: approve withdrawal
router.post("/admin/withdrawals/:id/approve", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.update(imperionWithdrawalsTable).set({ status: "approved" }).where(eq(imperionWithdrawalsTable.id, id));
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "approve withdrawal error");
    res.status(500).json({ error: "Failed to approve withdrawal" });
  }
});

// Admin: decline withdrawal — refund balance
router.post("/admin/withdrawals/:id/decline", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [w] = await db.select().from(imperionWithdrawalsTable).where(eq(imperionWithdrawalsTable.id, id)).limit(1);
    if (!w) { res.status(404).json({ error: "Withdrawal not found" }); return; }

    await db.update(imperionWithdrawalsTable).set({ status: "declined" }).where(eq(imperionWithdrawalsTable.id, id));

    // Refund balance
    const [user] = await db.select().from(imperionUsersTable).where(eq(imperionUsersTable.uid, w.uid)).limit(1);
    if (user) {
      const amt = parseFloat(w.amount);
      const type = (w.type ?? "").toLowerCase();
      const updates: any = {};
      if (type === "task") {
        updates.taskBalance = String(parseFloat(user.taskBalance ?? "0") + amt);
      } else if (type === "referral") {
        updates.referralBalance = String(parseFloat(user.referralBalance ?? "0") + amt);
      } else if (type === "daily") {
        updates.dailyClaimBalance = String(parseFloat(user.dailyClaimBalance ?? "0") + amt);
      } else {
        // Investment type — refund to premium balance
        updates.premiumBalance = String(parseFloat(user.premiumBalance ?? "0") + amt);
      }
      await db.update(imperionUsersTable).set(updates).where(eq(imperionUsersTable.uid, w.uid));
    }

    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "decline withdrawal error");
    res.status(500).json({ error: "Failed to decline withdrawal" });
  }
});

// ─── Tasks ──────────────────────────────────────────────────────────────────

router.get("/tasks", async (req, res) => {
  try {
    const rows = await db.select().from(imperionTasksTable)
      .orderBy(desc(imperionTasksTable.createdAt));
    res.json({
      tasks: rows.map(t => ({
        ...t,
        id: String(t.id),
        price: parseFloat(t.price),
        numberOfPeople: parseFloat(t.numberOfPeople ?? "0"),
      })),
    });
  } catch (err: any) {
    req.log.error(err, "get tasks error");
    res.status(500).json({ error: "Failed to get tasks" });
  }
});

// Admin: create task
router.post("/admin/tasks", requireAdmin, async (req, res) => {
  try {
    const { category, numberOfPeople, price, link, description } = req.body;
    if (!category || !price || !description) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const [inserted] = await db.insert(imperionTasksTable).values({
      category,
      numberOfPeople: String(numberOfPeople || 0),
      price: String(price),
      link,
      description,
    }).returning();
    res.json({
      task: { ...inserted, id: String(inserted.id), price: parseFloat(inserted.price), numberOfPeople: parseFloat(inserted.numberOfPeople ?? "0") },
    });
  } catch (err: any) {
    req.log.error(err, "create task error");
    res.status(500).json({ error: "Failed to create task" });
  }
});

// Admin: delete task
router.delete("/admin/tasks/:id", requireAdmin, async (req, res) => {
  try {
    await db.delete(imperionTasksTable).where(eq(imperionTasksTable.id, parseInt(req.params.id)));
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "delete task error");
    res.status(500).json({ error: "Failed to delete task" });
  }
});

// ─── Task Submissions ────────────────────────────────────────────────────────

router.post("/task-submissions", async (req, res) => {
  try {
    const { uid, username, taskId, taskTitle, taskAmount, proofImage } = req.body;
    if (!uid || !taskId) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const [inserted] = await db.insert(imperionTaskSubmissionsTable).values({
      uid, username,
      taskId: String(taskId),
      taskTitle,
      taskAmount: String(taskAmount || 0),
      proofImage,
      status: "pending",
    }).returning();
    res.json({ submission: { ...inserted, id: String(inserted.id), taskAmount: parseFloat(inserted.taskAmount ?? "0") } });
  } catch (err: any) {
    req.log.error(err, "create task submission error");
    res.status(500).json({ error: "Failed to submit task" });
  }
});

router.get("/task-submissions/user/:uid", async (req, res) => {
  try {
    const rows = await db.select({
      id: imperionTaskSubmissionsTable.id,
      uid: imperionTaskSubmissionsTable.uid,
      taskId: imperionTaskSubmissionsTable.taskId,
      taskTitle: imperionTaskSubmissionsTable.taskTitle,
      taskAmount: imperionTaskSubmissionsTable.taskAmount,
      status: imperionTaskSubmissionsTable.status,
      createdAt: imperionTaskSubmissionsTable.createdAt,
    }).from(imperionTaskSubmissionsTable)
      .where(eq(imperionTaskSubmissionsTable.uid, req.params.uid))
      .orderBy(desc(imperionTaskSubmissionsTable.createdAt));
    res.json({ submissions: rows.map(s => ({ ...s, id: String(s.id), taskAmount: parseFloat(s.taskAmount ?? "0") })) });
  } catch (err: any) {
    req.log.error(err, "get user submissions error");
    res.status(500).json({ error: "Failed to get submissions" });
  }
});

// Admin: get all task submissions
router.get("/admin/task-submissions", requireAdmin, async (req, res) => {
  try {
    const rows = await db.select().from(imperionTaskSubmissionsTable)
      .orderBy(desc(imperionTaskSubmissionsTable.createdAt));
    res.json({ submissions: rows.map(s => ({ ...s, id: String(s.id), taskAmount: parseFloat(s.taskAmount ?? "0") })) });
  } catch (err: any) {
    req.log.error(err, "admin get submissions error");
    res.status(500).json({ error: "Failed to get submissions" });
  }
});

// Admin: approve task submission
router.post("/admin/task-submissions/:id/approve", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [sub] = await db.select().from(imperionTaskSubmissionsTable).where(eq(imperionTaskSubmissionsTable.id, id)).limit(1);
    if (!sub) { res.status(404).json({ error: "Submission not found" }); return; }

    await db.update(imperionTaskSubmissionsTable).set({ status: "approved" }).where(eq(imperionTaskSubmissionsTable.id, id));

    // Credit user's task balance
    const [user] = await db.select().from(imperionUsersTable).where(eq(imperionUsersTable.uid, sub.uid)).limit(1);
    if (user) {
      const earned = parseFloat(sub.taskAmount ?? "0");
      await db.update(imperionUsersTable)
        .set({ taskBalance: String(parseFloat(user.taskBalance ?? "0") + earned) })
        .where(eq(imperionUsersTable.uid, sub.uid));
    }
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "approve submission error");
    res.status(500).json({ error: "Failed to approve submission" });
  }
});

// Admin: decline task submission
router.post("/admin/task-submissions/:id/decline", requireAdmin, async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.update(imperionTaskSubmissionsTable).set({ status: "declined" }).where(eq(imperionTaskSubmissionsTable.id, id));
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "decline submission error");
    res.status(500).json({ error: "Failed to decline submission" });
  }
});

// ─── Reviews ────────────────────────────────────────────────────────────────

router.get("/reviews", async (req, res) => {
  try {
    const rows = await db.select().from(imperionReviewsTable)
      .orderBy(desc(imperionReviewsTable.createdAt));
    res.json({ reviews: rows.map(r => ({ ...r, rating: parseFloat(r.rating ?? "5") })) });
  } catch (err: any) {
    req.log.error(err, "get reviews error");
    res.status(500).json({ error: "Failed to get reviews" });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const { name, text, rating } = req.body;
    if (!name || !text) { res.status(400).json({ error: "Missing required fields" }); return; }
    const [inserted] = await db.insert(imperionReviewsTable).values({
      name, text, rating: String(rating || 5),
    }).returning();
    res.json({ review: { ...inserted, rating: parseFloat(inserted.rating ?? "5") } });
  } catch (err: any) {
    req.log.error(err, "create review error");
    res.status(500).json({ error: "Failed to submit review" });
  }
});

// ─── Portal Status ──────────────────────────────────────────────────────────

router.get("/portal-status", async (req, res) => {
  try {
    const rows = await db.select().from(imperionPortalStatusTable).limit(1);
    if (rows.length === 0) {
      res.json({ referralClosed: false, taskClosed: false, dailyClosed: false, investmentClosed: false });
      return;
    }
    const r = rows[0];
    res.json({
      referralClosed: r.referralClosed,
      taskClosed: r.taskClosed,
      dailyClosed: r.dailyClosed,
      investmentClosed: r.investmentClosed,
    });
  } catch (err: any) {
    req.log.error(err, "get portal status error");
    res.status(500).json({ error: "Failed to get portal status" });
  }
});

router.put("/admin/portal-status", requireAdmin, async (req, res) => {
  try {
    const { referralClosed, taskClosed, dailyClosed, investmentClosed } = req.body;
    const rows = await db.select({ id: imperionPortalStatusTable.id }).from(imperionPortalStatusTable).limit(1);
    if (rows.length === 0) {
      await db.insert(imperionPortalStatusTable).values({
        referralClosed: !!referralClosed,
        taskClosed: !!taskClosed,
        dailyClosed: !!dailyClosed,
        investmentClosed: !!investmentClosed,
      });
    } else {
      await db.update(imperionPortalStatusTable)
        .set({ referralClosed: !!referralClosed, taskClosed: !!taskClosed, dailyClosed: !!dailyClosed, investmentClosed: !!investmentClosed })
        .where(eq(imperionPortalStatusTable.id, rows[0].id));
    }
    res.json({ ok: true });
  } catch (err: any) {
    req.log.error(err, "update portal status error");
    res.status(500).json({ error: "Failed to update portal status" });
  }
});

// ─── Airtime Orders ─────────────────────────────────────────────────────────

router.post("/airtime-orders", async (req, res) => {
  try {
    const { uid, username, email, mobile, network, type } = req.body;
    if (!uid || !mobile || !network) {
      res.status(400).json({ error: "Missing required fields" });
      return;
    }
    const [inserted] = await db.insert(imperionAirtimeOrdersTable).values({
      uid, username, email, mobile, network, type, amount: "200", status: "pending",
    }).returning();
    res.json({ order: inserted });
  } catch (err: any) {
    req.log.error(err, "create airtime order error");
    res.status(500).json({ error: "Failed to submit airtime order" });
  }
});

// ─── Admin: All Data ─────────────────────────────────────────────────────────

router.get("/admin/all-data", requireAdmin, async (req, res) => {
  try {
    const [withdrawals, deposits, taskSubmissions, users, tasks, portalRows] = await Promise.all([
      db.select().from(imperionWithdrawalsTable).orderBy(desc(imperionWithdrawalsTable.createdAt)),
      db.select().from(imperionDepositsTable).orderBy(desc(imperionDepositsTable.createdAt)),
      db.select().from(imperionTaskSubmissionsTable).orderBy(desc(imperionTaskSubmissionsTable.createdAt)),
      db.select().from(imperionUsersTable).orderBy(desc(imperionUsersTable.createdAt)),
      db.select().from(imperionTasksTable).orderBy(desc(imperionTasksTable.createdAt)),
      db.select().from(imperionPortalStatusTable).limit(1),
    ]);
    res.json({
      withdrawals: withdrawals.map(w => ({ ...w, amount: parseFloat(w.amount) })),
      deposits: deposits.map(d => ({ ...d, amount: parseFloat(d.amount) })),
      taskSubmissions: taskSubmissions.map(s => ({ ...s, id: String(s.id), taskAmount: parseFloat(s.taskAmount ?? "0") })),
      users: users.map(u => toUser(u)),
      tasks: tasks.map(t => ({ ...t, id: String(t.id), price: parseFloat(t.price), numberOfPeople: parseFloat(t.numberOfPeople ?? "0") })),
      portalStatus: portalRows.length > 0 ? portalRows[0] : { referralClosed: false, taskClosed: false, dailyClosed: false, investmentClosed: false },
    });
  } catch (err: any) {
    req.log.error(err, "admin all-data error");
    res.status(500).json({ error: "Failed to load admin data" });
  }
});

export default router;
