import { Router, type IRouter } from "express";
import healthRouter from "./health";
import imperionRouter from "./imperion";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/imperion", imperionRouter);

export default router;
