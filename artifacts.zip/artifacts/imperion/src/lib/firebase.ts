import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";

const firebaseConfig = {
  apiKey: "AIzaSyAzYzVq3Bzg1I5FT2onwGp_R6m2EiOUDGs",
  authDomain: "imperion-7f2e6.firebaseapp.com",
  projectId: "imperion-7f2e6",
  storageBucket: "imperion-7f2e6.firebasestorage.app",
  messagingSenderId: "75066635906",
  appId: "1:75066635906:web:a3e8b21a7648b7b6cf269b",
  measurementId: "G-GS5SYKSJ5C"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export default app;
