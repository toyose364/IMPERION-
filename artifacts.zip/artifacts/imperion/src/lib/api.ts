const BASE = "/api/imperion";

async function call<T = any>(method: string, path: string, body?: any): Promise<T> {
  const opts: RequestInit = { method, headers: { "Content-Type": "application/json" } };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(`${BASE}${path}`, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data as T;
}

function adminHeaders() {
  return { "Content-Type": "application/json", "x-admin-passcode": "2011" };
}

async function adminCall<T = any>(method: string, path: string, body?: any): Promise<T> {
  const opts: RequestInit = { method, headers: adminHeaders() };
  if (body !== undefined) opts.body = JSON.stringify(body);
  const res = await fetch(`${BASE}${path}`, opts);
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed: ${res.status}`);
  return data as T;
}

export const api = {
  // Auth
  signup: (payload: {
    uid: string; username: string; mobile: string; email: string;
    passwordHash: string; referralCode: string; referredBy: string; ipAddress: string;
  }) => call<{ user: any }>("POST", "/signup", payload),

  login: (email: string, passwordHash: string) =>
    call<{ user: any }>("POST", "/login", { email, passwordHash }),

  // User
  getUser: (uid: string) => call<{ user: any }>("GET", `/user/${uid}`),
  updateUser: (uid: string, data: Record<string, any>) =>
    call<{ user: any }>("PATCH", `/user/${uid}`, data),
  getUserByReferral: (code: string) =>
    call<{ uid: string }>("GET", `/user-by-referral/${encodeURIComponent(code)}`),
  getReferrals: (uid: string) =>
    call<{ referrals: any[] }>("GET", `/referrals/${uid}`),

  // Deposits
  submitDeposit: (data: { uid: string; username: string; email: string; amount: number; receiptImage: string }) =>
    call<{ deposit: any }>("POST", "/deposits", data),
  getUserDeposits: (uid: string) =>
    call<{ deposits: any[] }>("GET", `/deposits/user/${uid}`),

  // Withdrawals
  submitWithdrawal: (data: { uid: string; username: string; email: string; amount: number; type: string; bankName: string; accountNumber: string; accountHolder: string }) =>
    call<{ withdrawal: any }>("POST", "/withdrawals", data),
  getUserWithdrawals: (uid: string) =>
    call<{ withdrawals: any[] }>("GET", `/withdrawals/user/${uid}`),

  // Tasks
  getTasks: () => call<{ tasks: any[] }>("GET", "/tasks"),
  getUserTaskSubmissions: (uid: string) =>
    call<{ submissions: any[] }>("GET", `/task-submissions/user/${uid}`),
  submitTaskProof: (data: { uid: string; username: string; taskId: string; taskTitle: string; taskAmount: number; proofImage: string }) =>
    call<{ submission: any }>("POST", "/task-submissions", data),

  // Reviews
  getReviews: () => call<{ reviews: any[] }>("GET", "/reviews"),
  submitReview: (data: { name: string; text: string; rating: number }) =>
    call<{ review: any }>("POST", "/reviews", data),

  // Portal status
  getPortalStatus: () =>
    call<{ referralClosed: boolean; taskClosed: boolean; dailyClosed: boolean; investmentClosed: boolean }>("GET", "/portal-status"),

  // Airtime
  submitAirtimeOrder: (data: { uid: string; username: string; email: string; mobile: string; network: string; type: string }) =>
    call<{ order: any }>("POST", "/airtime-orders", data),

  // Admin
  admin: {
    getAllData: () => adminCall<{
      withdrawals: any[]; deposits: any[]; taskSubmissions: any[];
      users: any[]; tasks: any[]; portalStatus: any;
    }>("GET", "/admin/all-data"),
    approveDeposit: (id: number) => adminCall("POST", `/admin/deposits/${id}/approve`, {}),
    declineDeposit: (id: number) => adminCall("POST", `/admin/deposits/${id}/decline`, {}),
    approveWithdrawal: (id: number) => adminCall("POST", `/admin/withdrawals/${id}/approve`, {}),
    declineWithdrawal: (id: number) => adminCall("POST", `/admin/withdrawals/${id}/decline`, {}),
    approveTaskSubmission: (id: number) => adminCall("POST", `/admin/task-submissions/${id}/approve`, {}),
    declineTaskSubmission: (id: number) => adminCall("POST", `/admin/task-submissions/${id}/decline`, {}),
    createTask: (data: { category: string; numberOfPeople: number; price: number; link: string; description: string }) =>
      adminCall("POST", "/admin/tasks", data),
    deleteTask: (id: string) => adminCall("DELETE", `/admin/tasks/${id}`),
    updatePortalStatus: (data: { referralClosed: boolean; taskClosed: boolean; dailyClosed: boolean; investmentClosed: boolean }) =>
      adminCall("PUT", "/admin/portal-status", data),
  },
};
