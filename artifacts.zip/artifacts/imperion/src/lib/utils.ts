import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatNaira(amount: number): string {
  return `₦${amount.toLocaleString("en-NG", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function formatCountdown(ms: number): string {
  if (ms <= 0) return "00:00:00";
  const hours = Math.floor(ms / 3600000);
  const minutes = Math.floor((ms % 3600000) / 60000);
  const seconds = Math.floor((ms % 60000) / 1000);
  return `${String(hours).padStart(2, "0")}:${String(minutes).padStart(2, "0")}:${String(seconds).padStart(2, "0")}`;
}

export const WHATSAPP_LINK = "https://wa.me/2347084318814";
export const WHATSAPP_GROUP_NEWS = "https://chat.whatsapp.com/DkUVaf1ZIus1rxummUzXYW?mode=gi_t";
export const WHATSAPP_GROUP_COMMUNITY = "https://chat.whatsapp.com/Fjjnm7F5vIQHKaKZRFxakU?mode=gi_t";
export const WHATSAPP_PHONE = "+2347084318814";

