import { api } from "./api";

export interface User {
  uid: string;
  username: string;
  mobile: string;
  email: string;
  passwordHash: string;
  referralCode: string;
  referredBy?: string;
  ipAddress?: string;
  isActivated: boolean;
  taskBalance: number;
  referralBalance: number;
  depositBalance: number;
  dailyClaimBalance: number;
  hasClaimedAirtimeData: boolean;
  lastDailyClaim?: number;
  liteBalance: number;
  liteActivatedAt?: number;
  liteLastAccrual?: number;
  basicBalance: number;
  basicActivatedAt?: number;
  basicLastAccrual?: number;
  standardBalance: number;
  standardActivatedAt?: number;
  standardLastAccrual?: number;
  premiumBalance: number;
  premiumActivatedAt?: number;
  premiumLastAccrual?: number;
  createdAt?: any;
}

export function hashPassword(password: string): string {
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash;
  }
  return hash.toString(36);
}

export function generateReferralCode(username: string): string {
  const rand = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `IMP-${username.substring(0, 3).toUpperCase()}-${rand}`;
}

export async function getIPAddress(): Promise<string> {
  try {
    const res = await fetch("https://api.ipify.org?format=json", {
      signal: AbortSignal.timeout(5000),
    });
    const data = await res.json();
    return data.ip || "unknown";
  } catch {
    return "unknown";
  }
}

export async function signUp(
  username: string,
  mobile: string,
  email: string,
  password: string,
  referralCode?: string
): Promise<{ success: boolean; error?: string; user?: User }> {
  try {
    let ip = "unknown";
    try { ip = await getIPAddress(); } catch { /* ignore */ }

    // Resolve referredBy from referral code
    let referredBy = "";
    if (referralCode && referralCode.trim()) {
      try {
        const res = await api.getUserByReferral(referralCode.trim());
        referredBy = res.uid;
      } catch { /* invalid referral code — ignore */ }
    }

    const uid = `user_${Date.now()}_${Math.random().toString(36).substring(2)}`;
    const result = await api.signup({
      uid,
      username,
      mobile,
      email,
      passwordHash: hashPassword(password),
      referralCode: generateReferralCode(username),
      referredBy,
      ipAddress: ip,
    });

    return { success: true, user: result.user as User };
  } catch (err: any) {
    const msg = err?.message || "Sign up failed. Please check your internet connection and try again.";
    return { success: false, error: msg };
  }
}

export async function login(
  email: string,
  password: string
): Promise<{ success: boolean; error?: string; user?: User }> {
  try {
    const result = await api.login(email, hashPassword(password));
    return { success: true, user: result.user as User };
  } catch (err: any) {
    const msg = err?.message || "Login failed. Please check your internet connection and try again.";
    return { success: false, error: msg };
  }
}

export async function getUser(uid: string): Promise<User | null> {
  try {
    const result = await api.getUser(uid);
    return result.user as User;
  } catch {
    return null;
  }
}

export async function updateUser(uid: string, data: Partial<User>): Promise<void> {
  await api.updateUser(uid, data as Record<string, any>);
}
