import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { UserProvider, useUser } from "./context/UserContext";
import Layout from "./components/Layout";
import Landing from "./pages/Landing";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import History from "./pages/History";
import Referrals from "./pages/Referrals";
import Withdraw from "./pages/Withdraw";
import Tasks from "./pages/Tasks";
import Deposit from "./pages/Deposit";
import DailyBonus from "./pages/DailyBonus";
import Subscription from "./pages/Subscription";
import Invest from "./pages/Invest";
import Airtime from "./pages/Airtime";
import More from "./pages/More";
import PlaceAds from "./pages/PlaceAds";

const queryClient = new QueryClient();

function AppRoutes() {
  const { user, loading } = useUser();

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: "linear-gradient(135deg,#c00000,#e00000)" }}>
        <div style={{ textAlign: "center", color: "white" }}>
          <div style={{ fontSize: 40, fontWeight: 900, letterSpacing: 4, marginBottom: 16 }}>IMPERION</div>
          <div style={{ fontSize: 16, opacity: 0.85 }}>Loading...</div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <Switch>
        <Route path="/" component={Landing} />
        <Route path="/login" component={Login} />
        <Route path="/signup" component={Signup} />
        <Route component={Landing} />
      </Switch>
    );
  }

  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/dashboard" component={Dashboard} />
        <Route path="/history" component={History} />
        <Route path="/referrals" component={Referrals} />
        <Route path="/withdraw" component={Withdraw} />
        <Route path="/tasks" component={Tasks} />
        <Route path="/deposit" component={Deposit} />
        <Route path="/daily-bonus" component={DailyBonus} />
        <Route path="/subscription" component={Subscription} />
        <Route path="/invest" component={Invest} />
        <Route path="/airtime" component={Airtime} />
        <Route path="/more" component={More} />
        <Route path="/place-ads" component={PlaceAds} />
        <Route component={Dashboard} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <UserProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <AppRoutes />
        </WouterRouter>
      </UserProvider>
    </QueryClientProvider>
  );
}

export default App;
