import React, { useState } from "react";
import { useLocation } from "wouter";
import { useUser } from "../context/UserContext";
import AdminPanel from "../pages/AdminPanel";

const navItems = [
  { path: "/dashboard", icon: "🏠", label: "Home" },
  { path: "/tasks", icon: "✅", label: "Tasks" },
  { path: "/deposit", icon: "💰", label: "Deposit" },
  { path: "/withdraw", icon: "💳", label: "Withdraw" },
  { path: "/referrals", icon: "👥", label: "Refer" },
  { path: "/invest", icon: "📈", label: "Invest" },
  { path: "/more", icon: "☰", label: "More" },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();
  const { user, logout } = useUser();
  const [showAdmin, setShowAdmin] = useState(false);
  const [adminTaps, setAdminTaps] = useState(0);

  const handleAdminTap = () => {
    const next = adminTaps + 1;
    setAdminTaps(next);
    if (next >= 1) {
      setShowAdmin(true);
      setAdminTaps(0);
    }
  };

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column", background: "#f8f8f8", maxWidth: 480, margin: "0 auto", position: "relative" }}>
      {/* Top bar */}
      <div style={{ background: "linear-gradient(135deg,#c00000,#e00000)", padding: "12px 16px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ color: "white", fontWeight: 900, fontSize: 22, letterSpacing: 2 }}>IMPERION</div>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          {user && <div style={{ color: "white", fontSize: 13 }}>@{user.username}</div>}
          <button
            onClick={handleAdminTap}
            style={{ background: "rgba(255,255,255,0.2)", color: "white", border: "none", borderRadius: "50%", width: 32, height: 32, cursor: "pointer", fontWeight: 700, fontSize: 16 }}
          >A</button>
        </div>
      </div>

      {/* Main content */}
      <div style={{ flex: 1, overflowY: "auto", paddingBottom: 80 }}>
        {children}
      </div>

      {/* Bottom navigation */}
      <div style={{ position: "fixed", bottom: 0, left: "50%", transform: "translateX(-50%)", width: "100%", maxWidth: 480, background: "white", borderTop: "1px solid #e0e0e0", display: "flex", padding: "4px 0", zIndex: 100, boxShadow: "0 -2px 12px rgba(0,0,0,0.08)" }}>
        {navItems.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            style={{
              flex: 1,
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              gap: 2,
              padding: "6px 4px",
              border: "none",
              background: "none",
              cursor: "pointer",
              color: location === item.path ? "#c00000" : "#888",
              fontSize: 10,
              fontWeight: location === item.path ? 700 : 400,
            }}
          >
            <span style={{ fontSize: 18 }}>{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </div>

      {/* Admin Panel */}
      {showAdmin && <AdminPanel onClose={() => setShowAdmin(false)} />}
    </div>
  );
}
