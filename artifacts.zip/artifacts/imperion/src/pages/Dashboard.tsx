import React, { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { useUser } from "../context/UserContext";
import { formatNaira } from "../lib/utils";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { user, refreshUser } = useUser();
  const [online, setOnline] = useState(navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setOnline(true);
    const handleOffline = () => setOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    refreshUser();
    return () => { window.removeEventListener("online", handleOnline); window.removeEventListener("offline", handleOffline); };
  }, []);

  if (!user) return null;

  const investBalance = (user.liteBalance || 0) + (user.basicBalance || 0) + (user.standardBalance || 0) + (user.premiumBalance || 0);
  const totalBalance = (user.taskBalance || 0) + (user.referralBalance || 0) + (user.depositBalance || 0) + (user.dailyClaimBalance || 0) + investBalance;

  return (
    <div>
      {!online && (
        <div style={{ background: "#f8d7da", color: "#721c24", padding: "10px 16px", textAlign: "center", fontSize: 14, fontWeight: 600 }}>
          ⚠️ No Internet Connection
        </div>
      )}

      {!user.isActivated && (
        <div style={{ background: "#fff3cd", padding: "12px 16px", fontSize: 14, color: "#856404", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span>⚠️ Your account is not activated</span>
          <button onClick={() => navigate("/subscription")} style={{ background: "#c00000", color: "white", border: "none", borderRadius: 6, padding: "6px 12px", fontSize: 13, cursor: "pointer", fontWeight: 600 }}>Activate</button>
        </div>
      )}

      {/* Welcome */}
      <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", padding: "24px 20px", color: "white" }}>
        <div style={{ fontSize: 14, opacity: 0.85, marginBottom: 4 }}>Welcome back,</div>
        <div style={{ fontSize: 22, fontWeight: 800, marginBottom: 16 }}>@{user.username}</div>
        <div style={{ background: "rgba(255,255,255,0.15)", borderRadius: 16, padding: 20, backdropFilter: "blur(10px)" }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 4 }}>Total Balance</div>
          <div style={{ fontSize: 36, fontWeight: 900 }}>{formatNaira(totalBalance)}</div>
          <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
            {user.isActivated ? "✅ Account Active" : "❌ Account Not Activated"}
          </div>
        </div>
      </div>

      {/* Balance Cards */}
      <div style={{ padding: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {[
          { label: "Task Balance", value: user.taskBalance || 0, icon: "✅", color: "#c00000" },
          { label: "Referral Balance", value: user.referralBalance || 0, icon: "👥", color: "#e44" },
          { label: "Deposit Balance", value: user.depositBalance || 0, icon: "💰", color: "#c00000" },
          { label: "Daily Claim Balance", value: user.dailyClaimBalance || 0, icon: "🎁", color: "#e44" },
          { label: "Investment Balance", value: investBalance, icon: "📈", color: "#c00000" },
        ].map((card) => (
          <div key={card.label} style={{ background: "white", borderRadius: 12, padding: 16, border: "1px solid #f0e0e0", boxShadow: "0 2px 8px rgba(192,0,0,0.06)" }}>
            <div style={{ fontSize: 24, marginBottom: 8 }}>{card.icon}</div>
            <div style={{ fontSize: 11, color: "#888", marginBottom: 4 }}>{card.label}</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: card.color }}>{formatNaira(card.value)}</div>
          </div>
        ))}
      </div>

      {/* Quick Actions */}
      <div style={{ padding: "0 16px 16px" }}>
        <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Quick Actions</h3>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 8 }}>
          {[
            { icon: "✅", label: "Tasks", path: "/tasks" },
            { icon: "💰", label: "Deposit", path: "/deposit" },
            { icon: "💳", label: "Withdraw", path: "/withdraw" },
            { icon: "👥", label: "Refer", path: "/referrals" },
            { icon: "📈", label: "Invest", path: "/invest" },
            { icon: "🎁", label: "Daily Bonus", path: "/daily-bonus" },
            { icon: "📱", label: "Airtime", path: "/airtime" },
            { icon: "📋", label: "History", path: "/history" },
          ].map((a) => (
            <button key={a.path} onClick={() => navigate(a.path)} style={{ background: "white", border: "1px solid #f0e0e0", borderRadius: 12, padding: "12px 8px", display: "flex", flexDirection: "column", alignItems: "center", gap: 4, cursor: "pointer", transition: "all 0.2s" }}>
              <span style={{ fontSize: 24 }}>{a.icon}</span>
              <span style={{ fontSize: 11, color: "#555", fontWeight: 600 }}>{a.label}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Investment Breakdown */}
      <div style={{ margin: "0 16px 16px", background: "white", borderRadius: 12, padding: 16, border: "1px solid #f0e0e0" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333" }}>📈 Investment Machines</h3>
          <button onClick={() => navigate("/invest")} style={{ background: "#c00000", color: "white", border: "none", borderRadius: 8, padding: "4px 12px", fontSize: 12, cursor: "pointer", fontWeight: 600 }}>Manage</button>
        </div>
        {[
          { name: "Lite Machine", bal: user.liteBalance || 0, active: !!user.liteActivatedAt },
          { name: "Basic Machine", bal: user.basicBalance || 0, active: !!user.basicActivatedAt },
          { name: "Standard Machine", bal: user.standardBalance || 0, active: !!user.standardActivatedAt },
          { name: "Premium Machine", bal: user.premiumBalance || 0, active: !!user.premiumActivatedAt },
        ].map((m) => (
          <div key={m.name} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: "1px solid #f0f0f0" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <span style={{ fontSize: 13, color: "#555", fontWeight: 600 }}>{m.name}</span>
              {m.active ? (
                <span style={{ background: "#d4edda", color: "#155724", fontSize: 10, fontWeight: 700, padding: "2px 6px", borderRadius: 20 }}>ACTIVE</span>
              ) : (
                <span style={{ background: "#f8f8f8", color: "#999", fontSize: 10, fontWeight: 700, padding: "2px 6px", borderRadius: 20 }}>INACTIVE</span>
              )}
            </div>
            <span style={{ fontSize: 15, fontWeight: 800, color: m.active ? "#c00000" : "#ccc" }}>{formatNaira(m.bal)}</span>
          </div>
        ))}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", paddingTop: 10 }}>
          <span style={{ fontSize: 14, fontWeight: 700, color: "#333" }}>Total Investment</span>
          <span style={{ fontSize: 16, fontWeight: 900, color: "#c00000" }}>{formatNaira(investBalance)}</span>
        </div>
      </div>

      {/* Place Ads */}
      <div style={{ margin: "0 16px 16px", background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 12, padding: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ color: "white", fontWeight: 700, fontSize: 15 }}>Place Ads on IMPERION</div>
          <div style={{ color: "rgba(255,255,255,0.8)", fontSize: 13 }}>Reach thousands of users</div>
        </div>
        <a href="https://wa.me/2347084318814" target="_blank" rel="noreferrer" style={{ background: "white", color: "#c00000", borderRadius: 8, padding: "8px 14px", fontWeight: 700, fontSize: 13, textDecoration: "none" }}>Contact</a>
      </div>
    </div>
  );
}
