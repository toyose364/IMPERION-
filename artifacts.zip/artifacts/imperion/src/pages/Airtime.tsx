import React, { useState } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { formatNaira } from "../lib/utils";

const NETWORKS = ["MTN", "Airtel", "Glo", "9mobile"];
const AMOUNT = 200;

export default function Airtime() {
  const { user, updateUserData } = useUser();
  const [form, setForm] = useState({ mobile: "", network: "", type: "airtime" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const handle = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess(false);
    if (!user) return;
    if (!navigator.onLine) { setError("No internet connection"); return; }
    if (!user.isActivated) { setError("Activate your account first"); return; }
    if (user.hasClaimedAirtimeData) { setError("You have already used the airtime/data benefit"); return; }
    if ((user.taskBalance || 0) < 1000) { setError(`Your task balance must reach ₦1,000 first. Current: ${formatNaira(user.taskBalance || 0)}`); return; }
    if (!form.mobile || !form.network || !form.type) { setError("All fields are required"); return; }
    setLoading(true);
    try {
      await api.submitAirtimeOrder({
        uid: user.uid, username: user.username, email: user.email,
        mobile: form.mobile, network: form.network, type: form.type,
      });
      await updateUserData({
        taskBalance: (user.taskBalance || 0) - AMOUNT,
        hasClaimedAirtimeData: true,
      });
      setSuccess(true);
    } catch {
      setError("Failed to submit. Try again.");
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>📱</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Airtime & Data</div><div style={{ fontSize: 13, opacity: 0.85 }}>One-time ₦200 benefit</div></div>
      </div>

      <div style={{ padding: 16 }}>
        {user.hasClaimedAirtimeData ? (
          <div style={{ background: "#d4edda", borderRadius: 16, padding: 32, textAlign: "center" }}>
            <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
            <div style={{ fontWeight: 700, color: "#155724", fontSize: 18, marginBottom: 8 }}>Already Claimed</div>
            <div style={{ color: "#155724", fontSize: 14 }}>You have already used your one-time airtime/data benefit</div>
          </div>
        ) : (
          <>
            <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 16, padding: 20, color: "white", marginBottom: 16 }}>
              <div style={{ fontSize: 32, fontWeight: 900, marginBottom: 4 }}>{formatNaira(AMOUNT)}</div>
              <div style={{ fontSize: 14, opacity: 0.85 }}>One-time airtime or data purchase</div>
              <div style={{ fontSize: 12, opacity: 0.75, marginTop: 8 }}>Requires: Task balance ≥ ₦1,000 (current: {formatNaira(user.taskBalance || 0)})</div>
            </div>

            <div style={{ background: "#fff3cd", borderRadius: 8, padding: "10px 14px", fontSize: 13, color: "#856404", marginBottom: 16 }}>
              ⚠️ This is a one-time benefit. Choose carefully between Airtime or Data.
            </div>

            {error && <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>{error}</div>}
            {success && <div style={{ background: "#d4edda", border: "1px solid #c3e6cb", borderRadius: 8, padding: "10px 14px", color: "#155724", fontSize: 14, marginBottom: 16 }}>✅ Your airtime/data order has been submitted for processing!</div>}

            {(user.taskBalance || 0) >= 1000 && (
              <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
                <div className="form-group">
                  <label>Mobile Number</label>
                  <input className="input-field" placeholder="e.g. 08012345678" value={form.mobile} onChange={handle("mobile")} type="tel" />
                </div>
                <div className="form-group">
                  <label>Mobile Network</label>
                  <select className="input-field" value={form.network} onChange={handle("network") as any}>
                    <option value="">Select Network</option>
                    {NETWORKS.map(n => <option key={n} value={n}>{n}</option>)}
                  </select>
                </div>
                <div className="form-group">
                  <label>Choose One</label>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                    {["airtime", "data"].map((t) => (
                      <button key={t} type="button" onClick={() => setForm({ ...form, type: t })} style={{ padding: 14, borderRadius: 10, border: `2px solid ${form.type === t ? "#c00000" : "#e0e0e0"}`, background: form.type === t ? "#fff0f0" : "white", color: form.type === t ? "#c00000" : "#555", fontWeight: 700, fontSize: 15, cursor: "pointer", textTransform: "capitalize" }}>
                        {t === "airtime" ? "📞 Airtime" : "📶 Data"}
                      </button>
                    ))}
                  </div>
                </div>
                <div style={{ background: "#f8f8f8", borderRadius: 8, padding: 12, display: "flex", justifyContent: "space-between" }}>
                  <span style={{ color: "#555" }}>Amount:</span>
                  <span style={{ fontWeight: 700, color: "#c00000", fontSize: 18 }}>{formatNaira(AMOUNT)}</span>
                </div>
                <div style={{ fontSize: 13, color: "#888", textAlign: "center" }}>₦{AMOUNT} will be deducted from your task balance</div>
                <button className="btn-primary" type="submit" disabled={loading}>{loading ? "Processing..." : "Process"}</button>
              </form>
            )}
          </>
        )}
      </div>
    </div>
  );
}
