import React, { useState, useEffect } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { formatNaira, WHATSAPP_LINK } from "../lib/utils";

const MIN_REFERRAL = 1000;
const MIN_TASK = 2000;
const MIN_DAILY = 1000;
const MIN_INVEST = 1000;

type WithdrawType = "task" | "referral" | "daily" | "investment";

export default function Withdraw() {
  const { user, updateUserData } = useUser();
  const [type, setType] = useState<WithdrawType>("task");
  const [form, setForm] = useState({ bankName: "", accountNumber: "", accountHolder: "", amount: "" });
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [portalStatus, setPortalStatus] = useState<any>({});

  useEffect(() => {
    if (!user) return;
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    try {
      const [wRes, pRes] = await Promise.all([
        api.getUserWithdrawals(user.uid),
        api.getPortalStatus(),
      ]);
      setWithdrawals(wRes.withdrawals);
      setPortalStatus(pRes);
    } catch {}
  };

  const handle = (k: string) => (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const getBalance = () => {
    if (!user) return 0;
    if (type === "referral") return user.referralBalance || 0;
    if (type === "task") return user.taskBalance || 0;
    if (type === "daily") return user.dailyClaimBalance || 0;
    if (type === "investment") return (user.liteBalance || 0) + (user.basicBalance || 0) + (user.standardBalance || 0) + (user.premiumBalance || 0);
    return 0;
  };

  const getMin = () => {
    if (type === "referral") return MIN_REFERRAL;
    if (type === "task") return MIN_TASK;
    if (type === "daily") return MIN_DAILY;
    if (type === "investment") return MIN_INVEST;
    return 1000;
  };

  const isPortalClosed = () => {
    if (type === "referral" && portalStatus.referralClosed) return true;
    if (type === "task" && portalStatus.taskClosed) return true;
    if (type === "daily" && portalStatus.dailyClosed) return true;
    if (type === "investment" && portalStatus.investmentClosed) return true;
    return false;
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess(false);
    if (!navigator.onLine) { setError("No internet connection"); return; }
    if (!user?.isActivated) { setError("Activate your account first"); return; }
    if (isPortalClosed()) { setError("Withdrawal portal is currently closed. Please try again later."); return; }
    if (!form.bankName || !form.accountNumber || !form.accountHolder || !form.amount) { setError("All fields are required"); return; }
    const amt = parseFloat(form.amount);
    if (isNaN(amt) || amt < getMin()) { setError(`Minimum withdrawal is ${formatNaira(getMin())}`); return; }
    if (amt > getBalance()) { setError("Insufficient balance"); return; }

    setLoading(true);
    try {
      await api.submitWithdrawal({
        uid: user.uid, username: user.username, email: user.email,
        bankName: form.bankName, accountNumber: form.accountNumber,
        accountHolder: form.accountHolder, amount: amt, type,
      });

      // Immediately deduct balance
      if (type === "task") {
        await updateUserData({ taskBalance: Math.max(0, (user.taskBalance || 0) - amt) });
      } else if (type === "referral") {
        await updateUserData({ referralBalance: Math.max(0, (user.referralBalance || 0) - amt) });
      } else if (type === "daily") {
        await updateUserData({ dailyClaimBalance: Math.max(0, (user.dailyClaimBalance || 0) - amt) });
      } else if (type === "investment") {
        let remaining = amt;
        const updates: any = {};
        const lite = user.liteBalance || 0;
        const basic = user.basicBalance || 0;
        const standard = user.standardBalance || 0;
        const premium = user.premiumBalance || 0;
        if (remaining > 0 && lite > 0) { const take = Math.min(remaining, lite); updates.liteBalance = lite - take; remaining -= take; }
        if (remaining > 0 && basic > 0) { const take = Math.min(remaining, basic); updates.basicBalance = basic - take; remaining -= take; }
        if (remaining > 0 && standard > 0) { const take = Math.min(remaining, standard); updates.standardBalance = standard - take; remaining -= take; }
        if (remaining > 0 && premium > 0) { const take = Math.min(remaining, premium); updates.premiumBalance = premium - take; remaining -= take; }
        if (Object.keys(updates).length > 0) await updateUserData(updates);
      }

      setSuccess(true);
      setForm({ bankName: "", accountNumber: "", accountHolder: "", amount: "" });
      await loadData();
    } catch {
      setError("Failed to submit. Try again.");
    }
    setLoading(false);
  };

  if (!user) return null;

  const investBalance = (user.liteBalance || 0) + (user.basicBalance || 0) + (user.standardBalance || 0) + (user.premiumBalance || 0);

  return (
    <div>
      <div className="notice-bar">📢 Do you need a graphic designer? Contact us on WhatsApp +2347084318814</div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>💳</span>
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Withdrawal</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>Withdraw to your bank account</div>
        </div>
      </div>

      <div style={{ padding: 16 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8, marginBottom: 16 }}>
          {[
            { label: "Task", value: user.taskBalance || 0, key: "task" },
            { label: "Referral", value: user.referralBalance || 0, key: "referral" },
            { label: "Daily", value: user.dailyClaimBalance || 0, key: "daily" },
            { label: "Investment", value: investBalance, key: "investment" },
          ].map((b) => (
            <div key={b.key} onClick={() => setType(b.key as WithdrawType)}
              style={{ background: type === b.key ? "#fff0f0" : "white", borderRadius: 10, padding: "12px 10px", border: `2px solid ${type === b.key ? "#c00000" : "#e0e0e0"}`, cursor: "pointer", textAlign: "center" }}>
              <div style={{ fontSize: 14, fontWeight: 800, color: "#c00000" }}>{formatNaira(b.value)}</div>
              <div style={{ fontSize: 11, color: "#888", marginTop: 2 }}>{b.label}</div>
            </div>
          ))}
        </div>

        <div style={{ background: "#fff3cd", borderRadius: 8, padding: "10px 14px", fontSize: 13, color: "#856404", marginBottom: 16 }}>
          Min: Task ₦2,000 · Referral ₦1,000 · Daily ₦1,000 · Investment ₦1,000
        </div>

        {isPortalClosed() && (
          <div style={{ background: "#f8d7da", border: "1px solid #f5c6cb", borderRadius: 8, padding: "12px", color: "#721c24", fontWeight: 600, marginBottom: 16, textAlign: "center" }}>
            🚫 The {type} withdrawal portal is currently closed. Please check back later.
          </div>
        )}

        {error && (
          <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>
            {error}
          </div>
        )}
        {success && (
          <div style={{ background: "#d4edda", border: "1px solid #c3e6cb", borderRadius: 12, padding: 16, color: "#155724", fontSize: 14, marginBottom: 16, textAlign: "center" }}>
            <div style={{ fontSize: 28, marginBottom: 4 }}>✅</div>
            <div style={{ fontWeight: 700 }}>Withdrawal Submitted!</div>
            <div style={{ marginTop: 4, fontSize: 13 }}>Your balance has been updated. Admin will process your payment shortly.</div>
          </div>
        )}

        <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="form-group">
            <label>Withdrawal Type</label>
            <select className="input-field" value={type} onChange={(e) => setType(e.target.value as WithdrawType)}>
              <option value="task">Task Balance ({formatNaira(user.taskBalance || 0)})</option>
              <option value="referral">Referral Balance ({formatNaira(user.referralBalance || 0)})</option>
              <option value="daily">Daily Claim Balance ({formatNaira(user.dailyClaimBalance || 0)})</option>
              <option value="investment">Investment Balance ({formatNaira(investBalance)})</option>
            </select>
          </div>
          <div className="form-group">
            <label>Bank Name</label>
            <input className="input-field" placeholder="e.g. First Bank, GTB, Opay" value={form.bankName} onChange={handle("bankName")} />
          </div>
          <div className="form-group">
            <label>Account Number</label>
            <input className="input-field" placeholder="10-digit account number" value={form.accountNumber} onChange={handle("accountNumber")} inputMode="numeric" />
          </div>
          <div className="form-group">
            <label>Account Holder Name</label>
            <input className="input-field" placeholder="Full name on account" value={form.accountHolder} onChange={handle("accountHolder")} />
          </div>
          <div className="form-group">
            <label>Amount (₦)</label>
            <input className="input-field" placeholder={`Min: ₦${getMin().toLocaleString()} · Available: ${formatNaira(getBalance())}`} value={form.amount} onChange={handle("amount")} type="number" min={getMin()} />
          </div>
          <button className="btn-primary" type="submit" disabled={loading || isPortalClosed()}>
            {loading ? "Processing..." : "Process Withdrawal"}
          </button>
        </form>

        <div style={{ textAlign: "center", marginTop: 20 }}>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn">
            <span>💬</span> Customer Care
          </a>
        </div>

        {withdrawals.length > 0 && (
          <div style={{ marginTop: 24 }}>
            <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>My Withdrawals</h3>
            {withdrawals.map((w) => (
              <div key={w.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #f0e0e0" }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <div>
                    <div style={{ fontWeight: 700, color: "#333" }}>{formatNaira(w.amount)}</div>
                    <div style={{ fontSize: 12, color: "#888" }}>{w.bankName} · {w.type}</div>
                    <div style={{ fontSize: 12, color: "#888" }}>{w.createdAt ? new Date(w.createdAt).toLocaleDateString() : "N/A"}</div>
                  </div>
                  <span className={`status-badge status-${w.status || "pending"}`}>
                    {(w.status || "pending").charAt(0).toUpperCase() + (w.status || "pending").slice(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
