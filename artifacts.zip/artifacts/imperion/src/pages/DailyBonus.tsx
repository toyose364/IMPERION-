import React, { useState, useEffect } from "react";
import { useUser } from "../context/UserContext";
import { formatNaira, formatCountdown } from "../lib/utils";

const DAILY_AMOUNT = 100;
const COOLDOWN = 24 * 60 * 60 * 1000;

export default function DailyBonus() {
  const { user, updateUserData } = useUser();
  const [timeLeft, setTimeLeft] = useState(0);
  const [claimed, setClaimed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => {
    if (!user) return;
    const last = user.lastDailyClaim || 0;
    const diff = COOLDOWN - (Date.now() - last);
    setTimeLeft(Math.max(0, diff));
    const interval = setInterval(() => {
      const d = COOLDOWN - (Date.now() - (user.lastDailyClaim || 0));
      setTimeLeft(Math.max(0, d));
    }, 1000);
    return () => clearInterval(interval);
  }, [user]);

  const canClaim = timeLeft <= 0;

  const claim = async () => {
    if (!user || !canClaim) return;
    if (!navigator.onLine) { setMsg("No internet connection"); return; }
    if (!user.isActivated) { setMsg("Activate your account first"); return; }
    setLoading(true);
    try {
      await updateUserData({
        dailyClaimBalance: (user.dailyClaimBalance || 0) + DAILY_AMOUNT,
        lastDailyClaim: Date.now(),
      });
      setClaimed(true);
      setMsg(`✅ You claimed ${formatNaira(DAILY_AMOUNT)}!`);
      setTimeLeft(COOLDOWN);
    } catch {
      setMsg("Failed to claim. Try again.");
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>🎁</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Daily Bonus</div><div style={{ fontSize: 13, opacity: 0.85 }}>Claim ₦100 every 24 hours</div></div>
      </div>

      <div style={{ padding: 24 }}>
        {/* Big claim card */}
        <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 24, padding: 40, textAlign: "center", color: "white", marginBottom: 24 }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>🎁</div>
          <div style={{ fontSize: 40, fontWeight: 900, marginBottom: 8 }}>{formatNaira(DAILY_AMOUNT)}</div>
          <div style={{ fontSize: 15, opacity: 0.85, marginBottom: 24 }}>Daily Bonus Amount</div>

          {canClaim ? (
            <button onClick={claim} disabled={loading || !user.isActivated} style={{ background: "white", color: "#c00000", border: "none", borderRadius: 16, padding: "16px 40px", fontSize: 18, fontWeight: 800, cursor: "pointer", width: "100%" }}>
              {loading ? "Claiming..." : "🎉 Claim Now!"}
            </button>
          ) : (
            <div>
              <div style={{ background: "rgba(255,255,255,0.2)", borderRadius: 12, padding: 16, marginBottom: 8 }}>
                <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 4 }}>Next claim available in:</div>
                <div style={{ fontSize: 32, fontWeight: 900, fontFamily: "monospace" }}>{formatCountdown(timeLeft)}</div>
              </div>
              <div style={{ fontSize: 14, opacity: 0.8 }}>Come back after the countdown!</div>
            </div>
          )}
        </div>

        {msg && (
          <div style={{ background: msg.startsWith("✅") ? "#d4edda" : "#fee", border: `1px solid ${msg.startsWith("✅") ? "#c3e6cb" : "#fcc"}`, borderRadius: 8, padding: "12px 16px", color: msg.startsWith("✅") ? "#155724" : "#c00000", marginBottom: 16, fontWeight: 600, textAlign: "center" }}>
            {msg}
          </div>
        )}

        {/* Info */}
        <div style={{ background: "white", borderRadius: 16, padding: 20, marginBottom: 16, border: "1px solid #f0e0e0" }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>How it works</h3>
          {[
            "Claim ₦100 free daily bonus every 24 hours",
            "Bonus is added to your Daily Claim Balance",
            "Minimum withdrawal from daily balance: ₦1,000",
            "You must activate your account to claim",
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", gap: 8, marginBottom: 8, fontSize: 14, color: "#555" }}>
              <span style={{ color: "#c00000", fontWeight: 700 }}>•</span>
              <span>{item}</span>
            </div>
          ))}
        </div>

        {/* Balance */}
        <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 16, padding: 20, color: "white" }}>
          <div style={{ fontSize: 13, opacity: 0.85 }}>Daily Claim Balance</div>
          <div style={{ fontSize: 32, fontWeight: 900 }}>{formatNaira(user.dailyClaimBalance || 0)}</div>
        </div>
      </div>
    </div>
  );
}
