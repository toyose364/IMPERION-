import React, { useState, useEffect } from "react";
import { api } from "../lib/api";
import { formatNaira } from "../lib/utils";

const PASSCODE = "2011";

const TASK_CATEGORIES = [
  "WhatsApp group","WhatsApp channel","Telegram channel","Telegram group",
  "Tiktok likes","Tiktok followers","Tiktok views","Facebook followers",
  "Facebook group","Facebook reels views","Facebook reels likes",
  "YouTube channel followers","Tweeter retweet","Tweeter followers",
  "Instagram followers","Instagram likes","Instagram reels views",
  "Google links","Referrals link",
];

type AdminPage = "home" | "withdrawals" | "deposits" | "taskProofs" | "users" | "tasks" | "portals";

interface AdminPanelProps { onClose: () => void; }

export default function AdminPanel({ onClose }: AdminPanelProps) {
  const [code, setCode] = useState("");
  const [authed, setAuthed] = useState(false);
  const [codeError, setCodeError] = useState("");
  const [page, setPage] = useState<AdminPage>("home");

  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [taskProofs, setTaskProofs] = useState<any[]>([]);
  const [users, setUsers] = useState<any[]>([]);
  const [tasks, setTasks] = useState<any[]>([]);
  const [portalStatus, setPortalStatus] = useState<any>({ referralClosed: false, taskClosed: false, dailyClosed: false, investmentClosed: false });
  const [loading, setLoading] = useState(false);
  const [actionMsg, setActionMsg] = useState("");

  const [newTask, setNewTask] = useState({ category: "", numberOfPeople: "", price: "", link: "", description: "" });

  const verify = () => {
    if (code === PASSCODE) { setAuthed(true); loadAll(); }
    else setCodeError("Invalid passcode. Access denied.");
  };

  const loadAll = async () => {
    setLoading(true);
    try {
      const data = await api.admin.getAllData();
      setWithdrawals(data.withdrawals);
      setDeposits(data.deposits);
      setTaskProofs(data.taskSubmissions);
      setUsers(data.users);
      setTasks(data.tasks);
      setPortalStatus(data.portalStatus);
    } catch (err: any) {
      setActionMsg("Failed to load data: " + (err.message || "Unknown error"));
    }
    setLoading(false);
  };

  const act = async (fn: () => Promise<any>) => {
    setActionMsg("");
    try {
      await fn();
      await loadAll();
    } catch (err: any) {
      setActionMsg("Error: " + (err.message || "Unknown error"));
    }
  };

  const approveWithdrawal = (w: any) => act(() => api.admin.approveWithdrawal(w.id));
  const declineWithdrawal = (w: any) => act(() => api.admin.declineWithdrawal(w.id));
  const approveDeposit = (d: any) => act(() => api.admin.approveDeposit(d.id));
  const declineDeposit = (d: any) => act(() => api.admin.declineDeposit(d.id));
  const approveTaskProof = (t: any) => act(() => api.admin.approveTaskSubmission(parseInt(t.id)));
  const declineTaskProof = (t: any) => act(() => api.admin.declineTaskSubmission(parseInt(t.id)));

  const deleteTask = (id: string) => act(() => api.admin.deleteTask(id));

  const addTask = async () => {
    if (!newTask.category || !newTask.price || !newTask.description) {
      setActionMsg("Category, price and description are required");
      return;
    }
    await act(() => api.admin.createTask({
      category: newTask.category,
      numberOfPeople: parseInt(newTask.numberOfPeople) || 0,
      price: parseFloat(newTask.price),
      link: newTask.link,
      description: newTask.description,
    }));
    setNewTask({ category: "", numberOfPeople: "", price: "", link: "", description: "" });
  };

  const savePortal = async () => {
    await act(() => api.admin.updatePortalStatus(portalStatus));
    setActionMsg("✅ Portal settings saved!");
  };

  const StatusBadge = ({ status }: { status: string }) => (
    <span className={`status-badge status-${status}`}>{status.charAt(0).toUpperCase() + status.slice(1)}</span>
  );

  const formatDate = (d: any) => {
    if (!d) return "N/A";
    try { return new Date(d).toLocaleDateString(); } catch { return "N/A"; }
  };

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", zIndex: 1000, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
      <div style={{ background: "white", width: "100%", maxWidth: 480, height: "92vh", borderRadius: "24px 24px 0 0", display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ background: "linear-gradient(135deg,#1a0000,#c00000)", padding: "20px 20px 16px", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ color: "white", fontWeight: 900, fontSize: 18 }}>🔐 Admin Panel</div>
          <button onClick={onClose} style={{ background: "rgba(255,255,255,0.2)", color: "white", border: "none", borderRadius: "50%", width: 32, height: 32, cursor: "pointer", fontWeight: 700, fontSize: 18 }}>×</button>
        </div>

        <div style={{ flex: 1, overflowY: "auto" }}>
          {!authed ? (
            <div style={{ padding: 32 }}>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: "#333", marginBottom: 8 }}>Enter Passcode</h3>
              <p style={{ fontSize: 14, color: "#888", marginBottom: 20 }}>Enter the 4-digit admin passcode to access the panel</p>
              {codeError && <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>{codeError}</div>}
              <input className="input-field" placeholder="Enter 4-digit passcode" value={code} onChange={(e) => setCode(e.target.value)} type="password" maxLength={4} style={{ marginBottom: 16 }} onKeyDown={(e) => e.key === "Enter" && verify()} />
              <button className="btn-primary" onClick={verify}>Access Admin Panel</button>
            </div>
          ) : (
            <>
              <div style={{ display: "flex", overflowX: "auto", padding: "12px 16px", gap: 8, borderBottom: "1px solid #f0f0f0", background: "#f8f8f8" }}>
                {[
                  { key: "home", label: "Home" },
                  { key: "withdrawals", label: "Withdrawals" },
                  { key: "deposits", label: "Deposits" },
                  { key: "taskProofs", label: "Task Proofs" },
                  { key: "users", label: "Users" },
                  { key: "tasks", label: "Add Task" },
                  { key: "portals", label: "Portals" },
                ].map((p) => (
                  <button key={p.key} onClick={() => setPage(p.key as AdminPage)} style={{ whiteSpace: "nowrap", padding: "6px 14px", borderRadius: 20, border: `2px solid ${page === p.key ? "#c00000" : "#e0e0e0"}`, background: page === p.key ? "#c00000" : "white", color: page === p.key ? "white" : "#555", fontWeight: 600, fontSize: 13, cursor: "pointer" }}>
                    {p.label}
                  </button>
                ))}
              </div>

              <div style={{ padding: 16 }}>
                {loading && <div style={{ textAlign: "center", padding: 24, color: "#888" }}>Loading...</div>}
                {actionMsg && (
                  <div style={{ background: actionMsg.startsWith("✅") ? "#d4edda" : "#fee", border: `1px solid ${actionMsg.startsWith("✅") ? "#c3e6cb" : "#fcc"}`, borderRadius: 8, padding: "10px 14px", color: actionMsg.startsWith("✅") ? "#155724" : "#c00000", fontSize: 14, marginBottom: 16 }}>
                    {actionMsg}
                  </div>
                )}

                {page === "home" && (
                  <div>
                    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 16 }}>
                      {[
                        { label: "Total Users", value: users.length, icon: "👥", color: "#c00000" },
                        { label: "Pending Withdrawals", value: withdrawals.filter(w => w.status === "pending").length, icon: "💳", color: "#856404" },
                        { label: "Pending Deposits", value: deposits.filter(d => d.status === "pending").length, icon: "💰", color: "#155724" },
                        { label: "Pending Tasks", value: taskProofs.filter(t => t.status === "pending").length, icon: "✅", color: "#0056b3" },
                      ].map((s) => (
                        <div key={s.label} style={{ background: "white", borderRadius: 12, padding: 16, border: "1px solid #f0e0e0" }}>
                          <div style={{ fontSize: 24 }}>{s.icon}</div>
                          <div style={{ fontSize: 28, fontWeight: 900, color: s.color }}>{s.value}</div>
                          <div style={{ fontSize: 12, color: "#888" }}>{s.label}</div>
                        </div>
                      ))}
                    </div>
                    <button onClick={loadAll} style={{ width: "100%", background: "#f0f0f0", color: "#555", border: "none", borderRadius: 8, padding: "10px", cursor: "pointer", fontWeight: 600 }}>🔄 Refresh Data</button>
                  </div>
                )}

                {page === "withdrawals" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>All Withdrawal Requests ({withdrawals.length})</h3>
                    {withdrawals.length === 0 ? <div style={{ textAlign: "center", color: "#888", padding: 24 }}>No withdrawals yet</div> : withdrawals.map((w) => (
                      <div key={w.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 12, border: "1px solid #e0e0e0" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                          <div>
                            <div style={{ fontWeight: 700 }}>@{w.username}</div>
                            <div style={{ fontSize: 13, color: "#888" }}>{w.email}</div>
                            <div style={{ fontSize: 15, fontWeight: 800, color: "#c00000", marginTop: 4 }}>{formatNaira(w.amount)}</div>
                            <div style={{ fontSize: 12, color: "#888" }}>{w.type} | {w.bankName} | {w.accountNumber}</div>
                            <div style={{ fontSize: 12, color: "#888" }}>Holder: {w.accountHolder}</div>
                            <div style={{ fontSize: 12, color: "#aaa" }}>{formatDate(w.createdAt)}</div>
                          </div>
                          <StatusBadge status={w.status || "pending"} />
                        </div>
                        {w.status === "pending" && (
                          <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                            <button onClick={() => approveWithdrawal(w)} style={{ flex: 1, background: "#28a745", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>✅ Approve</button>
                            <button onClick={() => declineWithdrawal(w)} style={{ flex: 1, background: "#dc3545", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>❌ Decline</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {page === "deposits" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>All Deposit Receipts ({deposits.length})</h3>
                    {deposits.length === 0 ? <div style={{ textAlign: "center", color: "#888", padding: 24 }}>No deposits yet</div> : deposits.map((d) => (
                      <div key={d.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 12, border: "1px solid #e0e0e0" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                          <div>
                            <div style={{ fontWeight: 700 }}>@{d.username}</div>
                            <div style={{ fontSize: 15, fontWeight: 800, color: "#c00000" }}>{formatNaira(d.amount)}</div>
                            <div style={{ fontSize: 12, color: "#888" }}>{formatDate(d.createdAt)}</div>
                          </div>
                          <StatusBadge status={d.status || "pending"} />
                        </div>
                        {d.receiptImage && (
                          <img src={d.receiptImage} alt="Receipt" style={{ width: "100%", borderRadius: 8, marginBottom: 8, maxHeight: 200, objectFit: "contain" }} />
                        )}
                        {d.status === "pending" && (
                          <div style={{ display: "flex", gap: 8 }}>
                            <button onClick={() => approveDeposit(d)} style={{ flex: 1, background: "#28a745", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>✅ Approve</button>
                            <button onClick={() => declineDeposit(d)} style={{ flex: 1, background: "#dc3545", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>❌ Decline</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {page === "taskProofs" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Task Proof Submissions ({taskProofs.length})</h3>
                    {taskProofs.length === 0 ? <div style={{ textAlign: "center", color: "#888", padding: 24 }}>No task submissions yet</div> : taskProofs.map((t) => (
                      <div key={t.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 12, border: "1px solid #e0e0e0" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                          <div>
                            <div style={{ fontWeight: 700 }}>@{t.username}</div>
                            <div style={{ fontSize: 13, color: "#555" }}>{t.taskTitle}</div>
                            <div style={{ fontSize: 14, fontWeight: 700, color: "#c00000" }}>+{formatNaira(t.taskAmount || 0)}</div>
                            <div style={{ fontSize: 12, color: "#aaa" }}>{formatDate(t.createdAt)}</div>
                          </div>
                          <StatusBadge status={t.status || "pending"} />
                        </div>
                        {t.proofImage && (
                          <img src={t.proofImage} alt="Proof" style={{ width: "100%", borderRadius: 8, marginBottom: 8, maxHeight: 200, objectFit: "contain" }} />
                        )}
                        {t.status === "pending" && (
                          <div style={{ display: "flex", gap: 8 }}>
                            <button onClick={() => approveTaskProof(t)} style={{ flex: 1, background: "#28a745", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>✅ Approve</button>
                            <button onClick={() => declineTaskProof(t)} style={{ flex: 1, background: "#dc3545", color: "white", border: "none", borderRadius: 8, padding: "8px", cursor: "pointer", fontWeight: 700 }}>❌ Decline</button>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}

                {page === "users" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Total Users: {users.length}</h3>
                    {users.map((u) => (
                      <div key={u.uid} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #e0e0e0" }}>
                        <div style={{ fontWeight: 700, fontSize: 15 }}>@{u.username}</div>
                        <div style={{ fontSize: 12, color: "#888" }}>{u.email}</div>
                        <div style={{ fontSize: 13, color: "#555", marginTop: 4 }}>
                          Task: {formatNaira(u.taskBalance || 0)} · Ref: {formatNaira(u.referralBalance || 0)} · Deposit: {formatNaira(u.depositBalance || 0)}
                        </div>
                        <div style={{ fontSize: 12, color: u.isActivated ? "#155724" : "#856404", marginTop: 4 }}>
                          {u.isActivated ? "✅ Activated" : "⏳ Not Activated"}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {page === "tasks" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Add New Task</h3>
                    <div style={{ display: "flex", flexDirection: "column", gap: 12, marginBottom: 24 }}>
                      <div className="form-group">
                        <label>Category</label>
                        <select className="input-field" value={newTask.category} onChange={(e) => setNewTask({ ...newTask, category: e.target.value })}>
                          <option value="">Select Category</option>
                          {TASK_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                      </div>
                      <div className="form-group">
                        <label>Number of People</label>
                        <input className="input-field" placeholder="How many can perform this task" type="number" value={newTask.numberOfPeople} onChange={(e) => setNewTask({ ...newTask, numberOfPeople: e.target.value })} />
                      </div>
                      <div className="form-group">
                        <label>Price (₦)</label>
                        <input className="input-field" placeholder="Amount user earns" type="number" value={newTask.price} onChange={(e) => setNewTask({ ...newTask, price: e.target.value })} />
                      </div>
                      <div className="form-group">
                        <label>Link</label>
                        <input className="input-field" placeholder="Task link (WhatsApp group, etc.)" value={newTask.link} onChange={(e) => setNewTask({ ...newTask, link: e.target.value })} />
                      </div>
                      <div className="form-group">
                        <label>Description / Instructions</label>
                        <textarea className="input-field" rows={3} placeholder="Tell users how to perform this task" value={newTask.description} onChange={(e) => setNewTask({ ...newTask, description: e.target.value })} style={{ resize: "vertical" }} />
                      </div>
                      <button className="btn-primary" onClick={addTask}>Add Task</button>
                    </div>

                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Posted Tasks ({tasks.length})</h3>
                    {tasks.map((t) => (
                      <div key={t.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #e0e0e0" }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                          <div>
                            <div style={{ fontWeight: 700, fontSize: 15 }}>{t.category}</div>
                            <div style={{ fontSize: 13, color: "#888" }}>₦{t.price} · {t.numberOfPeople} people</div>
                          </div>
                          <button onClick={() => deleteTask(t.id)} style={{ background: "#dc3545", color: "white", border: "none", borderRadius: 8, padding: "6px 12px", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>Delete</button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {page === "portals" && (
                  <div>
                    <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 16 }}>Withdrawal Portal Control</h3>
                    {[
                      { key: "referralClosed", label: "Referral Withdrawal Portal" },
                      { key: "taskClosed", label: "Task Withdrawal Portal" },
                      { key: "dailyClosed", label: "Daily Claim Withdrawal Portal" },
                      { key: "investmentClosed", label: "Investment Withdrawal Portal" },
                    ].map((p) => (
                      <div key={p.key} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 12, border: "1px solid #e0e0e0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                        <div>
                          <div style={{ fontWeight: 700, color: "#333" }}>{p.label}</div>
                          <div style={{ fontSize: 13, color: (portalStatus as any)[p.key] ? "#721c24" : "#155724" }}>
                            {(portalStatus as any)[p.key] ? "🔴 CLOSED" : "🟢 OPEN"}
                          </div>
                        </div>
                        <button onClick={() => setPortalStatus({ ...portalStatus, [p.key]: !(portalStatus as any)[p.key] })}
                          style={{ background: (portalStatus as any)[p.key] ? "#28a745" : "#dc3545", color: "white", border: "none", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontWeight: 700 }}>
                          {(portalStatus as any)[p.key] ? "Open" : "Close"}
                        </button>
                      </div>
                    ))}
                    <button className="btn-primary" onClick={savePortal} style={{ marginTop: 8 }}>Save Portal Settings</button>
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
