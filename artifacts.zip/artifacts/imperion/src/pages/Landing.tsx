import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { api } from "../lib/api";
import { WHATSAPP_LINK, WHATSAPP_GROUP_NEWS, WHATSAPP_GROUP_COMMUNITY } from "../lib/utils";
import licensImg from "@assets/IMG-20260403-WA0027_1775385153083.jpg";

const fakeReviews = [
  { name: "Chioma E.", text: "I earned ₦15,000 in just two weeks! IMPERION is real and pays fast.", rating: 5, date: "Mar 2026" },
  { name: "Emeka J.", text: "Best earning platform in Nigeria. The tasks are easy and payment is quick.", rating: 5, date: "Mar 2026" },
  { name: "Fatima A.", text: "I've tried many platforms but IMPERION is different. Legit and transparent!", rating: 5, date: "Feb 2026" },
  { name: "Bola T.", text: "My referral bonus came in within hours. Very reliable platform.", rating: 5, date: "Feb 2026" },
  { name: "Kelechi O.", text: "The investment machines are amazing. Passive income every 24 hours!", rating: 5, date: "Jan 2026" },
  { name: "Ngozi S.", text: "Customer support is always available. Love this platform so much!", rating: 5, date: "Jan 2026" },
];

export default function Landing() {
  const [, navigate] = useLocation();
  const [reviews, setReviews] = useState<any[]>([]);
  const [reviewName, setReviewName] = useState("");
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(5);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  useEffect(() => {
    loadReviews();
  }, []);

  const loadReviews = async () => {
    try {
      const res = await api.getReviews();
      setReviews([...res.reviews, ...fakeReviews]);
    } catch {
      setReviews(fakeReviews);
    }
  };

  const submitReview = async () => {
    if (!reviewName.trim() || !reviewText.trim()) return;
    setSubmitting(true);
    try {
      await api.submitReview({ name: reviewName.trim(), text: reviewText.trim(), rating: reviewRating });
      setSubmitted(true);
      setReviewName("");
      setReviewText("");
      await loadReviews();
    } catch {
      alert("Failed to submit review. Try again.");
    }
    setSubmitting(false);
  };

  return (
    <div style={{ minHeight: "100vh", fontFamily: "Inter, sans-serif" }}>
      {/* Header */}
      <div style={{ background: "linear-gradient(135deg,#c00000,#e00000)", padding: "16px 20px", display: "flex", justifyContent: "space-between", alignItems: "center", position: "sticky", top: 0, zIndex: 100 }}>
        <div style={{ color: "white", fontWeight: 900, fontSize: 26, letterSpacing: 3 }}>IMPERION</div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => navigate("/login")} style={{ background: "rgba(255,255,255,0.2)", color: "white", border: "1px solid rgba(255,255,255,0.5)", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontWeight: 600 }}>Login</button>
          <button onClick={() => navigate("/signup")} style={{ background: "white", color: "#c00000", border: "none", borderRadius: 8, padding: "8px 16px", cursor: "pointer", fontWeight: 700 }}>Sign Up</button>
        </div>
      </div>

      {/* Hero */}
      <div style={{ background: "linear-gradient(135deg,#c00000 0%,#ff4444 50%,#ff8888 100%)", color: "white", padding: "60px 24px", textAlign: "center" }}>
        <h1 style={{ fontSize: 42, fontWeight: 900, marginBottom: 16, lineHeight: 1.2 }}>Earn Money Online with <span style={{ color: "#FFD700" }}>IMPERION</span></h1>
        <p style={{ fontSize: 18, opacity: 0.9, maxWidth: 500, margin: "0 auto 32px", lineHeight: 1.6 }}>Nigeria's most trusted earning platform. Complete tasks, refer friends, invest and earn daily rewards!</p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <button onClick={() => navigate("/signup")} style={{ background: "white", color: "#c00000", border: "none", borderRadius: 12, padding: "14px 32px", fontSize: 18, fontWeight: 800, cursor: "pointer" }}>Start Earning Now</button>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ fontSize: 16, padding: "14px 24px" }}>
            <span>💬</span> WhatsApp Us
          </a>
        </div>
      </div>

      {/* License Banner - Top */}
      <div style={{ background: "#fff8f0", borderBottom: "3px solid #c8a000", padding: "20px 16px", textAlign: "center" }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: "#856404", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>🏛️ CBN Licensed & Regulated</div>
        <img src={licensImg} alt="CBN Payment Solution Service Provider License - IMPERION Finance Hub Nigeria Limited" style={{ maxWidth: "100%", width: 480, borderRadius: 12, boxShadow: "0 4px 20px rgba(0,0,0,0.15)", border: "2px solid #d4a017" }} />
        <div style={{ fontSize: 12, color: "#888", marginTop: 8 }}>License No: CBN/PSSP/IMPERION/2026/0042 · Valid until April 4, 2029</div>
      </div>

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 1, background: "#e0e0e0", borderBottom: "1px solid #e0e0e0" }}>
        {[
          { label: "Active Users", value: "10,000+" },
          { label: "Total Paid", value: "₦50M+" },
          { label: "Daily Tasks", value: "500+" },
        ].map((stat) => (
          <div key={stat.label} style={{ background: "white", padding: "24px 16px", textAlign: "center" }}>
            <div style={{ fontSize: 28, fontWeight: 900, color: "#c00000" }}>{stat.value}</div>
            <div style={{ fontSize: 13, color: "#666", marginTop: 4 }}>{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Features */}
      <div style={{ padding: "48px 24px", background: "#fff8f8" }}>
        <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 800, color: "#c00000", marginBottom: 32 }}>Why Choose IMPERION?</h2>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 20 }}>
          {[
            { icon: "✅", title: "Easy Tasks", desc: "Complete simple social media tasks and earn money instantly" },
            { icon: "👥", title: "Referral Bonus", desc: "Earn 10% of your referred user's first deposit automatically" },
            { icon: "📈", title: "Investment Machines", desc: "Activate machines and earn daily passive income every 24 hours" },
            { icon: "🎁", title: "Daily Bonus", desc: "Claim ₦100 free every 24 hours just for logging in" },
            { icon: "💳", title: "Fast Withdrawals", desc: "Withdraw to any Nigerian bank account quickly and securely" },
            { icon: "🔒", title: "100% Secure", desc: "Your data and money are safe with our advanced security" },
          ].map((f) => (
            <div key={f.title} style={{ background: "white", borderRadius: 16, padding: 24, border: "1px solid #f0e0e0", boxShadow: "0 2px 12px rgba(192,0,0,0.06)" }}>
              <div style={{ fontSize: 36, marginBottom: 12 }}>{f.icon}</div>
              <h3 style={{ fontSize: 18, fontWeight: 700, color: "#333", marginBottom: 8 }}>{f.title}</h3>
              <p style={{ fontSize: 14, color: "#666", lineHeight: 1.6 }}>{f.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* How It Works */}
      <div style={{ padding: "48px 24px", background: "white" }}>
        <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 800, color: "#c00000", marginBottom: 32 }}>How It Works</h2>
        <div style={{ maxWidth: 600, margin: "0 auto" }}>
          {[
            { step: 1, title: "Sign Up", desc: "Create your free account with your name, email and mobile number" },
            { step: 2, title: "Activate Account", desc: "Deposit ₦1,000 to activate your IMPERION account" },
            { step: 3, title: "Complete Tasks", desc: "Browse available tasks, complete them and upload proof" },
            { step: 4, title: "Earn & Withdraw", desc: "Watch your balance grow and withdraw to your bank account" },
          ].map((step) => (
            <div key={step.step} style={{ display: "flex", gap: 16, marginBottom: 24, alignItems: "flex-start" }}>
              <div style={{ minWidth: 48, height: 48, background: "linear-gradient(135deg,#c00000,#e00000)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontWeight: 800, fontSize: 20 }}>{step.step}</div>
              <div>
                <h3 style={{ fontSize: 18, fontWeight: 700, color: "#333", marginBottom: 4 }}>{step.title}</h3>
                <p style={{ fontSize: 14, color: "#666", lineHeight: 1.6 }}>{step.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Reviews */}
      <div style={{ padding: "48px 24px", background: "#fff8f8" }}>
        <h2 style={{ textAlign: "center", fontSize: 28, fontWeight: 800, color: "#c00000", marginBottom: 8 }}>What Users Say</h2>
        <p style={{ textAlign: "center", color: "#888", marginBottom: 32 }}>Real reviews from real IMPERION members</p>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16, marginBottom: 40 }}>
          {reviews.slice(0, 6).map((r, i) => (
            <div key={i} style={{ background: "white", borderRadius: 16, padding: 20, border: "1px solid #f0e0e0", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 12 }}>
                <div>
                  <div style={{ fontWeight: 700, color: "#333" }}>{r.name}</div>
                  {r.date && <div style={{ fontSize: 12, color: "#888" }}>{r.date}</div>}
                </div>
                <div style={{ color: "#FFD700", fontSize: 16 }}>{"★".repeat(r.rating || 5)}</div>
              </div>
              <p style={{ fontSize: 14, color: "#555", lineHeight: 1.6, fontStyle: "italic" }}>"{r.text}"</p>
            </div>
          ))}
        </div>

        {/* Write Review */}
        <div style={{ background: "white", borderRadius: 16, padding: 24, border: "1px solid #f0e0e0", maxWidth: 500, margin: "0 auto" }}>
          <h3 style={{ fontSize: 20, fontWeight: 700, color: "#333", marginBottom: 16 }}>Write a Review</h3>
          {submitted ? (
            <div style={{ textAlign: "center", color: "#c00000", fontWeight: 700, padding: 24 }}>Thank you for your review!</div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
              <input className="input-field" placeholder="Your Name" value={reviewName} onChange={(e) => setReviewName(e.target.value)} />
              <textarea className="input-field" placeholder="Share your experience..." rows={3} value={reviewText} onChange={(e) => setReviewText(e.target.value)} style={{ resize: "vertical" }} />
              <div style={{ display: "flex", gap: 4 }}>
                {[1,2,3,4,5].map((s) => (
                  <button key={s} onClick={() => setReviewRating(s)} style={{ fontSize: 24, background: "none", border: "none", cursor: "pointer", color: s <= reviewRating ? "#FFD700" : "#ccc" }}>★</button>
                ))}
              </div>
              <button className="btn-primary" onClick={submitReview} disabled={submitting}>{submitting ? "Submitting..." : "Submit Review"}</button>
            </div>
          )}
        </div>
      </div>

      {/* WhatsApp Groups */}
      <div style={{ padding: "32px 24px", background: "linear-gradient(135deg,#c00000,#e00000)", textAlign: "center" }}>
        <h3 style={{ color: "white", fontSize: 22, fontWeight: 800, marginBottom: 8 }}>Join Our Communities</h3>
        <p style={{ color: "rgba(255,255,255,0.85)", marginBottom: 24 }}>Stay updated with the latest news and connect with other members</p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <a href={WHATSAPP_GROUP_NEWS} target="_blank" rel="noreferrer" className="whatsapp-btn">📢 IMPERION NEWS</a>
          <a href={WHATSAPP_GROUP_COMMUNITY} target="_blank" rel="noreferrer" className="whatsapp-btn">👥 Community Group</a>
        </div>
      </div>

      {/* CTA */}
      <div style={{ padding: "48px 24px", background: "white", textAlign: "center" }}>
        <h2 style={{ fontSize: 28, fontWeight: 800, color: "#333", marginBottom: 16 }}>Ready to Start Earning?</h2>
        <p style={{ color: "#666", marginBottom: 24, fontSize: 16 }}>Join thousands of Nigerians already earning with IMPERION</p>
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
          <button onClick={() => navigate("/signup")} className="btn-primary" style={{ maxWidth: 200 }}>Create Account</button>
          <button onClick={() => navigate("/login")} className="btn-secondary" style={{ maxWidth: 200 }}>Login</button>
        </div>
      </div>

      {/* License Banner - Bottom */}
      <div style={{ background: "#fff8f0", borderTop: "3px solid #c8a000", padding: "28px 16px", textAlign: "center" }}>
        <div style={{ fontSize: 14, fontWeight: 700, color: "#856404", marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>🏛️ Officially Licensed by the Central Bank of Nigeria</div>
        <img src={licensImg} alt="CBN Payment Solution Service Provider License - IMPERION Finance Hub Nigeria Limited" style={{ maxWidth: "100%", width: 480, borderRadius: 12, boxShadow: "0 4px 20px rgba(0,0,0,0.15)", border: "2px solid #d4a017" }} />
        <p style={{ fontSize: 13, color: "#666", marginTop: 12, maxWidth: 480, margin: "12px auto 0" }}>IMPERION Finance Hub Nigeria Limited is fully licensed and regulated under CBN License No. CBN/PSSP/IMPERION/2026/0042 as a Payment Solution Service Provider.</p>
      </div>

      {/* Footer */}
      <div style={{ background: "#1a0000", color: "#888", padding: "24px", textAlign: "center", fontSize: 13 }}>
        <div style={{ color: "white", fontWeight: 700, fontSize: 18, marginBottom: 8 }}>IMPERION</div>
        <p>Nigeria's Premier Online Earning Platform</p>
        <p style={{ marginTop: 8 }}>© 2026 IMPERION. All rights reserved.</p>
      </div>
    </div>
  );
}
