import React, { useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { formatNaira } from "../lib/utils";

export default function History() {
  const { user } = useUser();
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!user) return;
    loadHistory();
  }, [user]);

  const loadHistory = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [dRes, wRes] = await Promise.all([
        api.getUserDeposits(user.uid),
        api.getUserWithdrawals(user.uid),
      ]);
      setDeposits(dRes.deposits);
      setWithdrawals(wRes.withdrawals);
    } catch {}
    setLoading(false);
  };

  const approvedDeposits = deposits.filter(d => d.status === "approved");
  const declinedDeposits = deposits.filter(d => d.status === "declined");
  const approvedWithdrawals = withdrawals.filter(w => w.status === "approved");
  const declinedWithdrawals = withdrawals.filter(w => w.status === "declined");

  const StatusBadge = ({ status }: { status: string }) => (
    <span className={`status-badge status-${status}`}>{status.charAt(0).toUpperCase() + status.slice(1)}</span>
  );

  const fmt = (d: any) => {
    if (!d) return "N/A";
    try { return new Date(d).toLocaleDateString(); } catch { return "N/A"; }
  };

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>📋</span>
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Transaction History</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>All your deposits and withdrawals</div>
        </div>
      </div>

      <div style={{ padding: 16, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
        {[
          { label: "Approved Deposits", value: approvedDeposits.length, color: "#155724", bg: "#d4edda" },
          { label: "Declined Deposits", value: declinedDeposits.length, color: "#721c24", bg: "#f8d7da" },
          { label: "Approved Withdrawals", value: approvedWithdrawals.length, color: "#155724", bg: "#d4edda" },
          { label: "Declined Withdrawals", value: declinedWithdrawals.length, color: "#721c24", bg: "#f8d7da" },
        ].map((s) => (
          <div key={s.label} style={{ background: s.bg, borderRadius: 12, padding: "16px 14px" }}>
            <div style={{ fontSize: 28, fontWeight: 900, color: s.color }}>{s.value}</div>
            <div style={{ fontSize: 12, color: s.color, fontWeight: 600, marginTop: 4 }}>{s.label}</div>
          </div>
        ))}
      </div>

      {loading ? (
        <div style={{ textAlign: "center", padding: 40, color: "#888" }}>Loading...</div>
      ) : (
        <div style={{ padding: "0 16px 16px" }}>
          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Deposit History</h3>
          {deposits.length === 0 ? (
            <div style={{ background: "white", borderRadius: 12, padding: 24, textAlign: "center", color: "#888", marginBottom: 24 }}>No deposit records yet</div>
          ) : (
            <div style={{ marginBottom: 24 }}>
              {deposits.map((d) => (
                <div key={d.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #f0e0e0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <div>
                    <div style={{ fontWeight: 700, color: "#333" }}>{formatNaira(d.amount || 0)}</div>
                    <div style={{ fontSize: 12, color: "#888" }}>{fmt(d.createdAt)}</div>
                  </div>
                  <StatusBadge status={d.status || "pending"} />
                </div>
              ))}
            </div>
          )}

          <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>Withdrawal History</h3>
          {withdrawals.length === 0 ? (
            <div style={{ background: "white", borderRadius: 12, padding: 24, textAlign: "center", color: "#888" }}>No withdrawal records yet</div>
          ) : (
            withdrawals.map((w) => (
              <div key={w.id} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #f0e0e0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                <div>
                  <div style={{ fontWeight: 700, color: "#333" }}>{formatNaira(w.amount || 0)}</div>
                  <div style={{ fontSize: 12, color: "#888" }}>{w.type} • {fmt(w.createdAt)}</div>
                </div>
                <StatusBadge status={w.status || "pending"} />
              </div>
            ))
          )}
        </div>
      )}
    </div>
  );
}
