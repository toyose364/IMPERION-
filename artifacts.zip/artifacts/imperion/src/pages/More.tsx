import React from "react";
import { useLocation } from "wouter";
import { useUser } from "../context/UserContext";
import { WHATSAPP_LINK } from "../lib/utils";

export default function More() {
  const [, navigate] = useLocation();
  const { user, logout } = useUser();

  const items = [
    { icon: "🎁", label: "Daily Bonus", path: "/daily-bonus", desc: "Claim ₦100 every 24 hours" },
    { icon: "📋", label: "History", path: "/history", desc: "Your transaction history" },
    { icon: "⚡", label: "Activation", path: "/subscription", desc: "Activate your account" },
    { icon: "📱", label: "Airtime & Data", path: "/airtime", desc: "One-time ₦200 purchase" },
    { icon: "📢", label: "Place Ads", path: "/place-ads", desc: "Advertise on IMPERION" },
  ];

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>☰</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>More Options</div><div style={{ fontSize: 13, opacity: 0.85 }}>All IMPERION features</div></div>
      </div>

      <div style={{ padding: 16 }}>
        {/* User card */}
        {user && (
          <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 16, padding: 20, color: "white", marginBottom: 16 }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>👤</div>
            <div style={{ fontWeight: 800, fontSize: 18 }}>@{user.username}</div>
            <div style={{ fontSize: 13, opacity: 0.85 }}>{user.email}</div>
            <div style={{ marginTop: 8, fontSize: 12, background: "rgba(255,255,255,0.2)", display: "inline-block", padding: "4px 10px", borderRadius: 20 }}>
              {user.isActivated ? "✅ Activated" : "❌ Not Activated"}
            </div>
          </div>
        )}

        {/* Menu items */}
        <div style={{ background: "white", borderRadius: 16, border: "1px solid #f0e0e0", overflow: "hidden", marginBottom: 16 }}>
          {items.map((item, i) => (
            <button key={item.path} onClick={() => navigate(item.path)} style={{ width: "100%", display: "flex", alignItems: "center", gap: 14, padding: "16px 20px", border: "none", background: "none", cursor: "pointer", borderBottom: i < items.length - 1 ? "1px solid #f0f0f0" : "none", textAlign: "left" }}>
              <span style={{ fontSize: 24, minWidth: 32 }}>{item.icon}</span>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, color: "#333", fontSize: 15 }}>{item.label}</div>
                <div style={{ fontSize: 12, color: "#888" }}>{item.desc}</div>
              </div>
              <span style={{ color: "#ccc" }}>›</span>
            </button>
          ))}
        </div>

        {/* Customer Care */}
        <div style={{ background: "white", borderRadius: 16, padding: 20, border: "1px solid #f0e0e0", marginBottom: 16, textAlign: "center" }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#333", marginBottom: 12 }}>Need help?</div>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn"><span>💬</span> Customer Care</a>
        </div>

        {/* Logout */}
        <button onClick={() => { logout(); window.location.href = "/"; }} style={{ width: "100%", background: "#f8f8f8", color: "#c00000", border: "2px solid #c00000", borderRadius: 12, padding: "14px", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
          Logout
        </button>
      </div>
    </div>
  );
}
