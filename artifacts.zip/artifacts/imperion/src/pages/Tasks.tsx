import React, { useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { compressImageToBase64 } from "../lib/imageUtils";
import { WHATSAPP_LINK } from "../lib/utils";

export default function Tasks() {
  const { user } = useUser();
  const [tasks, setTasks] = useState<any[]>([]);
  const [mySubmissions, setMySubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTask, setActiveTask] = useState<any>(null);
  const [proof, setProof] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState("");

  useEffect(() => { loadTasks(); }, [user]);

  const loadTasks = async () => {
    setLoading(true);
    try {
      const [tasksRes, subsRes] = await Promise.all([
        api.getTasks(),
        user ? api.getUserTaskSubmissions(user.uid) : Promise.resolve({ submissions: [] }),
      ]);
      setTasks(tasksRes.tasks);
      setMySubmissions(subsRes.submissions);
    } catch {}
    setLoading(false);
  };

  const handleProofChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setProof(file);
    if (file) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    } else {
      setPreviewUrl("");
    }
  };

  const getSubmission = (taskId: string) => mySubmissions.find(s => s.taskId === taskId);
  const pendingCount = mySubmissions.filter(s => s.status === "pending").length;
  const approvedCount = mySubmissions.filter(s => s.status === "approved").length;
  const declinedCount = mySubmissions.filter(s => s.status === "declined").length;

  const submitTask = async () => {
    if (!user || !activeTask || !proof) return;
    setMsg("");
    if (!proof.type.startsWith("image/")) { setMsg("Please upload an image file"); return; }
    setSubmitting(true);
    try {
      setMsg("Compressing image...");
      const base64 = await compressImageToBase64(proof);
      setMsg("Submitting...");
      await api.submitTaskProof({
        uid: user.uid,
        username: user.username,
        taskId: activeTask.id,
        taskTitle: activeTask.category,
        taskAmount: activeTask.price,
        proofImage: base64,
      });
      setMsg("✅ Task submitted! Waiting for approval.");
      setActiveTask(null);
      setProof(null);
      setPreviewUrl("");
      await loadTasks();
    } catch {
      setMsg("Failed to submit. Please check your connection and try again.");
    }
    setSubmitting(false);
  };

  if (!user) return null;

  return (
    <div>
      <div className="notice-bar">💻 Do you need a website? Contact us today on WhatsApp +2347084318814</div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>✅</span>
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Task Center</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>Complete tasks and earn money</div>
        </div>
      </div>

      {!user.isActivated && (
        <div style={{ background: "#fff3cd", padding: "12px 16px", fontSize: 14, color: "#856404", textAlign: "center", fontWeight: 600 }}>
          ⚠️ Activate your account to perform tasks
        </div>
      )}

      <div style={{ padding: 16 }}>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8, marginBottom: 16 }}>
          {[
            { label: "Pending", value: pendingCount, color: "#856404", bg: "#fff3cd" },
            { label: "Approved", value: approvedCount, color: "#155724", bg: "#d4edda" },
            { label: "Declined", value: declinedCount, color: "#721c24", bg: "#f8d7da" },
          ].map((s) => (
            <div key={s.label} style={{ background: s.bg, borderRadius: 10, padding: "12px 8px", textAlign: "center" }}>
              <div style={{ fontSize: 24, fontWeight: 900, color: s.color }}>{s.value}</div>
              <div style={{ fontSize: 11, color: s.color, fontWeight: 600 }}>{s.label}</div>
            </div>
          ))}
        </div>

        {activeTask && (
          <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 200, display: "flex", alignItems: "flex-end", justifyContent: "center" }}>
            <div style={{ background: "white", borderRadius: "24px 24px 0 0", padding: 24, width: "100%", maxWidth: 480, maxHeight: "90vh", overflowY: "auto" }}>
              <h3 style={{ fontWeight: 800, fontSize: 18, color: "#333", marginBottom: 8 }}>{activeTask.category}</h3>
              <div style={{ fontSize: 14, color: "#c00000", fontWeight: 700, marginBottom: 12 }}>Reward: ₦{activeTask.price}</div>
              <div style={{ background: "#f8f8f8", borderRadius: 8, padding: 12, marginBottom: 16, fontSize: 14, color: "#555", lineHeight: 1.6 }}>
                {activeTask.description}
              </div>
              {activeTask.link && (
                <a href={activeTask.link} target="_blank" rel="noreferrer" style={{ display: "block", background: "#c00000", color: "white", textAlign: "center", borderRadius: 8, padding: "12px", textDecoration: "none", fontWeight: 700, marginBottom: 16 }}>
                  🔗 Open Task Link
                </a>
              )}

              <div style={{ marginBottom: 8, fontSize: 14, fontWeight: 600 }}>Upload Task Proof (Image Only)</div>
              <div style={{ border: "2px dashed #ddd", borderRadius: 12, padding: 16, textAlign: "center", marginBottom: 12, cursor: "pointer", background: "#fafafa" }}
                onClick={() => document.getElementById("taskProofInput")?.click()}>
                {previewUrl ? (
                  <img src={previewUrl} alt="Preview" style={{ maxWidth: "100%", maxHeight: 180, borderRadius: 8, objectFit: "contain" }} />
                ) : (
                  <div>
                    <div style={{ fontSize: 32, marginBottom: 8 }}>📷</div>
                    <div style={{ fontSize: 14, color: "#888" }}>Tap to select image</div>
                    <div style={{ fontSize: 12, color: "#bbb", marginTop: 4 }}>JPG, PNG, etc.</div>
                  </div>
                )}
              </div>
              <input id="taskProofInput" type="file" accept="image/*" onChange={handleProofChange} style={{ display: "none" }} />
              {proof && <div style={{ fontSize: 13, color: "#155724", marginBottom: 8 }}>✅ {proof.name}</div>}

              {msg && (
                <div style={{ fontSize: 13, padding: "8px 12px", borderRadius: 8, marginBottom: 12, background: msg.startsWith("✅") ? "#d4edda" : "#fff3cd", color: msg.startsWith("✅") ? "#155724" : "#856404", fontWeight: 600 }}>
                  {msg}
                </div>
              )}

              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => { setActiveTask(null); setProof(null); setPreviewUrl(""); setMsg(""); }}
                  style={{ flex: 1, background: "#f0f0f0", color: "#555", border: "none", borderRadius: 8, padding: 12, cursor: "pointer", fontWeight: 600 }}>
                  Cancel
                </button>
                <button onClick={submitTask} disabled={!proof || submitting} className="btn-primary" style={{ flex: 2 }}>
                  {submitting ? "Processing..." : "Process Task"}
                </button>
              </div>
            </div>
          </div>
        )}

        {loading ? (
          <div style={{ textAlign: "center", padding: 40, color: "#888" }}>Loading tasks...</div>
        ) : tasks.length === 0 ? (
          <div style={{ background: "white", borderRadius: 12, padding: 32, textAlign: "center", color: "#888" }}>
            <div style={{ fontSize: 40, marginBottom: 8 }}>✅</div>
            <div>No tasks available right now. Check back soon!</div>
          </div>
        ) : (
          tasks.map((task) => {
            const submission = getSubmission(task.id);
            return (
              <div key={task.id} className="task-card">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 8 }}>
                  <div>
                    <div style={{ fontWeight: 700, color: "#333", fontSize: 15 }}>{task.category}</div>
                    <div style={{ fontSize: 12, color: "#888", marginTop: 2 }}>Reward: <span style={{ color: "#c00000", fontWeight: 700 }}>₦{task.price}</span></div>
                  </div>
                  {submission ? (
                    <span className={`status-badge status-${submission.status}`}>
                      {submission.status.charAt(0).toUpperCase() + submission.status.slice(1)}
                    </span>
                  ) : (
                    <span style={{ background: "#e8f5e9", color: "#2e7d32", borderRadius: 50, padding: "3px 10px", fontSize: 12, fontWeight: 600 }}>
                      Available
                    </span>
                  )}
                </div>
                {task.description && (
                  <p style={{ fontSize: 13, color: "#666", marginBottom: 12, lineHeight: 1.5 }}>{task.description}</p>
                )}
                {!submission && user.isActivated && (
                  <button onClick={() => { setActiveTask(task); setMsg(""); setProof(null); setPreviewUrl(""); }}
                    style={{ background: "linear-gradient(135deg,#c00000,#e00000)", color: "white", border: "none", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontWeight: 700, fontSize: 14, width: "100%" }}>
                    Start Task
                  </button>
                )}
                {!user.isActivated && (
                  <div style={{ fontSize: 12, color: "#856404", fontStyle: "italic" }}>Activate your account to start tasks</div>
                )}
              </div>
            );
          })
        )}

        <div style={{ textAlign: "center", marginTop: 20 }}>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn">
            <span>💬</span> Customer Care
          </a>
        </div>
      </div>
    </div>
  );
}
