import React, { useEffect, useState } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { formatNaira } from "../lib/utils";

export default function Referrals() {
  const { user } = useUser();
  const [referrals, setReferrals] = useState<any[]>([]);
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);

  const referralLink = user ? `${window.location.origin}/?ref=${user.referralCode}` : "";

  useEffect(() => {
    if (!user) return;
    loadReferrals();
  }, [user]);

  const loadReferrals = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const res = await api.getReferrals(user.uid);
      setReferrals(res.referrals);
    } catch {}
    setLoading(false);
  };

  const copyLink = () => {
    navigator.clipboard.writeText(referralLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  const copyCode = () => {
    navigator.clipboard.writeText(user?.referralCode || "").then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>👥</span>
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Referrals</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>Earn 10% of each referral's first deposit</div>
        </div>
      </div>

      <div style={{ padding: 16 }}>
        <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 16, padding: 24, color: "white", marginBottom: 16 }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 4 }}>Referral Balance</div>
          <div style={{ fontSize: 36, fontWeight: 900 }}>{formatNaira(user.referralBalance || 0)}</div>
          <div style={{ fontSize: 13, opacity: 0.75, marginTop: 4 }}>Total Referrals: {referrals.length}</div>
        </div>

        <div style={{ background: "#fff3cd", borderRadius: 12, padding: 16, marginBottom: 16, border: "1px solid #ffc107" }}>
          <div style={{ fontWeight: 700, color: "#856404", marginBottom: 4 }}>💰 How Referral Bonus Works</div>
          <div style={{ fontSize: 14, color: "#856404" }}>You earn 10% of your referred user's first deposit. Minimum withdrawal: ₦1,000</div>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 12, border: "1px solid #f0e0e0" }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#555", marginBottom: 8 }}>Your Referral Code</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ flex: 1, background: "#f8f8f8", borderRadius: 8, padding: "10px 14px", fontWeight: 700, color: "#c00000", fontSize: 18, letterSpacing: 2 }}>{user.referralCode}</div>
            <button onClick={copyCode} style={{ background: "#c00000", color: "white", border: "none", borderRadius: 8, padding: "10px 16px", cursor: "pointer", fontWeight: 600, whiteSpace: "nowrap" }}>
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>

        <div style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 16, border: "1px solid #f0e0e0" }}>
          <div style={{ fontSize: 14, fontWeight: 600, color: "#555", marginBottom: 8 }}>Your Referral Link</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ flex: 1, background: "#f8f8f8", borderRadius: 8, padding: "10px 14px", fontSize: 12, color: "#666", wordBreak: "break-all" }}>{referralLink}</div>
            <button onClick={copyLink} style={{ background: "#c00000", color: "white", border: "none", borderRadius: 8, padding: "10px 16px", cursor: "pointer", fontWeight: 600, whiteSpace: "nowrap" }}>
              {copied ? "Copied!" : "Copy"}
            </button>
          </div>
        </div>

        <a href={`https://wa.me/?text=Join%20IMPERION%20and%20earn%20money%20online!%20Use%20my%20referral%20link:%20${encodeURIComponent(referralLink)}`} target="_blank" rel="noreferrer" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#25D366", color: "white", borderRadius: 12, padding: "14px", textDecoration: "none", fontWeight: 700, fontSize: 16, marginBottom: 20 }}>
          📲 Share on WhatsApp
        </a>

        <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>My Referrals ({referrals.length})</h3>
        {loading ? (
          <div style={{ textAlign: "center", padding: 24, color: "#888" }}>Loading...</div>
        ) : referrals.length === 0 ? (
          <div style={{ background: "white", borderRadius: 12, padding: 24, textAlign: "center", color: "#888" }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>👥</div>
            <div>No referrals yet. Share your link to start earning!</div>
          </div>
        ) : (
          referrals.map((r) => (
            <div key={r.uid} style={{ background: "white", borderRadius: 12, padding: 16, marginBottom: 8, border: "1px solid #f0e0e0", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div>
                <div style={{ fontWeight: 700, color: "#333" }}>@{r.username}</div>
                <div style={{ fontSize: 12, color: "#888" }}>{r.isActivated ? "✅ Activated" : "⏳ Not activated"}</div>
              </div>
              <div style={{ fontSize: 13, color: "#c00000", fontWeight: 600 }}>
                {r.isActivated ? formatNaira((r.depositBalance || 0) * 0.1) : "₦0.00"}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
