import React, { useState } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { compressImageToBase64 } from "../lib/imageUtils";
import { WHATSAPP_LINK } from "../lib/utils";

const ACCOUNT_DETAILS = {
  name: "Favour Ifedayo Sam Ayinde",
  number: "7084318814",
  bank: "Opay",
};

export default function Deposit() {
  const { user } = useUser();
  const [amount, setAmount] = useState("");
  const [receipt, setReceipt] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState("");
  const [copied, setCopied] = useState<string>("");

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    setTimeout(() => setCopied(""), 2000);
  };

  const handleReceiptChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    setReceipt(file);
    if (file) {
      const url = URL.createObjectURL(file);
      setPreviewUrl(url);
    } else {
      setPreviewUrl("");
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(""); setSuccess(false);
    if (!navigator.onLine) { setError("No internet connection"); return; }
    if (!user) { setError("Please log in"); return; }
    if (!amount || parseFloat(amount) < 1000) { setError("Minimum deposit is ₦1,000"); return; }
    if (!receipt) { setError("Please upload your deposit receipt"); return; }
    if (!receipt.type.startsWith("image/")) { setError("Receipt must be an image file"); return; }
    setLoading(true);
    try {
      const base64 = await compressImageToBase64(receipt);
      await api.submitDeposit({
        uid: user.uid,
        username: user.username,
        email: user.email,
        amount: parseFloat(amount),
        receiptImage: base64,
      });
      setSuccess(true);
      setAmount("");
      setReceipt(null);
      setPreviewUrl("");
    } catch {
      setError("Failed to submit. Please check your connection and try again.");
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>💰</span>
        <div>
          <div style={{ fontWeight: 800, fontSize: 18 }}>Deposit</div>
          <div style={{ fontSize: 13, opacity: 0.85 }}>Fund your account</div>
        </div>
      </div>

      <div style={{ padding: 16 }}>
        <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 16, padding: 20, color: "white", marginBottom: 16 }}>
          <div style={{ fontSize: 13, opacity: 0.85, marginBottom: 12 }}>Transfer to this account:</div>
          {[
            { label: "Account Name", value: ACCOUNT_DETAILS.name },
            { label: "Account Number", value: ACCOUNT_DETAILS.number },
            { label: "Bank", value: ACCOUNT_DETAILS.bank },
          ].map((d) => (
            <div key={d.label} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
              <div>
                <div style={{ fontSize: 11, opacity: 0.75 }}>{d.label}</div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>{d.value}</div>
              </div>
              <button onClick={() => copy(d.value, d.label)}
                style={{ background: "rgba(255,255,255,0.2)", color: "white", border: "1px solid rgba(255,255,255,0.4)", borderRadius: 6, padding: "6px 12px", cursor: "pointer", fontSize: 12, fontWeight: 600 }}>
                {copied === d.label ? "✓ Copied!" : "Copy"}
              </button>
            </div>
          ))}
        </div>

        <div style={{ background: "#fff3cd", borderRadius: 8, padding: "10px 14px", fontSize: 13, color: "#856404", marginBottom: 16 }}>
          ⚠️ Minimum deposit: ₦1,000. After transferring, upload your receipt below.
        </div>

        {error && (
          <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>
            {error}
          </div>
        )}
        {success && (
          <div style={{ background: "#d4edda", border: "1px solid #c3e6cb", borderRadius: 12, padding: "16px", color: "#155724", fontSize: 14, marginBottom: 16, textAlign: "center" }}>
            <div style={{ fontSize: 32, marginBottom: 8 }}>✅</div>
            <div style={{ fontWeight: 700, fontSize: 16 }}>Receipt Submitted!</div>
            <div style={{ marginTop: 4 }}>Admin will review and approve your deposit shortly.</div>
          </div>
        )}

        <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          <div className="form-group">
            <label>Amount Deposited (₦)</label>
            <input className="input-field" placeholder="Enter amount (Min: ₦1,000)" value={amount}
              onChange={(e) => setAmount(e.target.value)} type="number" min="1000" />
          </div>

          <div className="form-group">
            <label>Upload Deposit Receipt</label>
            <div style={{ border: "2px dashed #ddd", borderRadius: 12, padding: 16, textAlign: "center", cursor: "pointer", background: "#fafafa" }}
              onClick={() => document.getElementById("receiptInput")?.click()}>
              {previewUrl ? (
                <img src={previewUrl} alt="Receipt preview" style={{ maxWidth: "100%", maxHeight: 200, borderRadius: 8, objectFit: "contain" }} />
              ) : (
                <div>
                  <div style={{ fontSize: 36, marginBottom: 8 }}>📄</div>
                  <div style={{ fontSize: 14, color: "#888" }}>Tap to select receipt image</div>
                  <div style={{ fontSize: 12, color: "#bbb", marginTop: 4 }}>JPG, PNG supported</div>
                </div>
              )}
            </div>
            <input id="receiptInput" type="file" accept="image/*" onChange={handleReceiptChange} style={{ display: "none" }} />
            {receipt && <div style={{ fontSize: 13, color: "#155724", marginTop: 4 }}>✅ {receipt.name}</div>}
          </div>

          <button className="btn-primary" type="submit" disabled={loading}>
            {loading ? "Uploading & Submitting..." : "Process Deposit"}
          </button>
        </form>

        <div style={{ textAlign: "center", marginTop: 20 }}>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn">
            <span>💬</span> Customer Care
          </a>
        </div>
      </div>
    </div>
  );
}
