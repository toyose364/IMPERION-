import React, { useState, useEffect } from "react";
import { useUser } from "../context/UserContext";
import { api } from "../lib/api";
import { formatNaira, formatCountdown } from "../lib/utils";

const MACHINES = [
  { key: "lite", name: "Lite Machine", activation: 500, dailyProfit: 100, minWithdraw: 1000, color: "#6c757d" },
  { key: "basic", name: "Basic Machine", activation: 1000, dailyProfit: 200, minWithdraw: 1500, color: "#007bff" },
  { key: "standard", name: "Standard Machine", activation: 1500, dailyProfit: 300, minWithdraw: 2000, color: "#28a745" },
  { key: "premium", name: "Premium Machine", activation: 2000, dailyProfit: 400, minWithdraw: 2500, color: "#c00000" },
] as const;

type MachineKey = "lite" | "basic" | "standard" | "premium";

export default function Invest() {
  const { user, updateUserData } = useUser();
  const [loading, setLoading] = useState<MachineKey | null>(null);
  const [withdrawing, setWithdrawing] = useState<MachineKey | null>(null);
  const [withdrawForm, setWithdrawForm] = useState({ bankName: "", accountNumber: "", accountHolder: "", amount: "" });
  const [msg, setMsg] = useState("");
  const [now, setNow] = useState(Date.now());

  useEffect(() => {
    const interval = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!user) return;
    const accrueInterval = setInterval(async () => {
      const updates: Partial<any> = {};
      let changed = false;
      for (const m of MACHINES) {
        const activatedAt = user[`${m.key}ActivatedAt` as keyof typeof user] as number | undefined;
        if (!activatedAt) continue;
        const lastAccrual = (user[`${m.key}LastAccrual` as keyof typeof user] as number) || activatedAt;
        const diff = Date.now() - lastAccrual;
        if (diff >= 24 * 60 * 60 * 1000) {
          const cycles = Math.floor(diff / (24 * 60 * 60 * 1000));
          const earned = cycles * m.dailyProfit;
          updates[`${m.key}Balance`] = ((user[`${m.key}Balance` as keyof typeof user] as number) || 0) + earned;
          updates[`${m.key}LastAccrual`] = lastAccrual + cycles * 24 * 60 * 60 * 1000;
          changed = true;
        }
      }
      if (changed) await updateUserData(updates);
    }, 60000);
    return () => clearInterval(accrueInterval);
  }, [user]);

  const getTimeToNext = (key: MachineKey) => {
    if (!user) return 0;
    const activatedAt = (user as any)[`${key}ActivatedAt`] as number | undefined;
    if (!activatedAt) return 0;
    const lastAccrual = (user as any)[`${key}LastAccrual`] as number || activatedAt;
    const nextAccrual = lastAccrual + 24 * 60 * 60 * 1000;
    return Math.max(0, nextAccrual - now);
  };

  const activateMachine = async (m: typeof MACHINES[number]) => {
    if (!user) return;
    setMsg("");
    if (!user.isActivated) { setMsg("Activate your account first"); return; }
    if ((user.depositBalance || 0) < m.activation) { setMsg(`Insufficient deposit balance. Need ${formatNaira(m.activation)}`); return; }
    if ((user as any)[`${m.key}ActivatedAt`]) { setMsg(`${m.name} already activated`); return; }
    setLoading(m.key);
    try {
      await updateUserData({
        depositBalance: (user.depositBalance || 0) - m.activation,
        [`${m.key}ActivatedAt`]: Date.now(),
        [`${m.key}LastAccrual`]: Date.now(),
        [`${m.key}Balance`]: 0,
      } as any);
      setMsg(`✅ ${m.name} activated successfully!`);
    } catch {
      setMsg("Activation failed. Try again.");
    }
    setLoading(null);
  };

  const submitWithdrawal = async (m: typeof MACHINES[number]) => {
    if (!user) return;
    setMsg("");
    const amt = parseFloat(withdrawForm.amount);
    if (!withdrawForm.bankName || !withdrawForm.accountNumber || !withdrawForm.accountHolder || !withdrawForm.amount) { setMsg("All fields required"); return; }
    if (isNaN(amt) || amt < m.minWithdraw) { setMsg(`Minimum withdrawal: ${formatNaira(m.minWithdraw)}`); return; }
    const bal = (user as any)[`${m.key}Balance`] as number || 0;
    if (amt > bal) { setMsg("Insufficient balance"); return; }
    setWithdrawing(m.key);
    try {
      await api.submitWithdrawal({
        uid: user.uid, username: user.username, email: user.email,
        bankName: withdrawForm.bankName, accountNumber: withdrawForm.accountNumber,
        accountHolder: withdrawForm.accountHolder, amount: amt,
        type: `${m.name} Investment`,
      });
      await updateUserData({ [`${m.key}Balance`]: bal - amt } as any);
      setMsg(`✅ Withdrawal of ${formatNaira(amt)} submitted!`);
      setWithdrawing(null);
      setWithdrawForm({ bankName: "", accountNumber: "", accountHolder: "", amount: "" });
    } catch {
      setMsg("Failed. Try again.");
    }
    setWithdrawing(null);
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>📈</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Investment Machines</div><div style={{ fontSize: 13, opacity: 0.85 }}>Earn daily passive income</div></div>
      </div>

      <div style={{ padding: 16 }}>
        {msg && (
          <div style={{ background: msg.startsWith("✅") ? "#d4edda" : "#fee", border: `1px solid ${msg.startsWith("✅") ? "#c3e6cb" : "#fcc"}`, borderRadius: 8, padding: "10px 14px", color: msg.startsWith("✅") ? "#155724" : "#c00000", marginBottom: 16, fontWeight: 600 }}>{msg}</div>
        )}

        {MACHINES.map((m) => {
          const activated = !!(user as any)[`${m.key}ActivatedAt`];
          const balance = (user as any)[`${m.key}Balance`] as number || 0;
          const timeLeft = getTimeToNext(m.key);
          const showWithdraw = withdrawing === m.key;

          return (
            <div key={m.key} className="machine-card" style={{ marginBottom: 16, borderColor: activated ? m.color : "#e0e0e0" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <div>
                  <div style={{ fontWeight: 800, fontSize: 16, color: "#333" }}>{m.name}</div>
                  <div style={{ fontSize: 13, color: "#888", marginTop: 2 }}>Daily Profit: <strong style={{ color: m.color }}>+{formatNaira(m.dailyProfit)}</strong></div>
                  <div style={{ fontSize: 13, color: "#888" }}>Activation: {formatNaira(m.activation)}</div>
                </div>
                {activated && (
                  <button onClick={() => setWithdrawing(showWithdraw ? null : m.key)} style={{ background: m.color, color: "white", border: "none", borderRadius: 8, padding: "8px 14px", cursor: "pointer", fontWeight: 700, fontSize: 13 }}>
                    💳 Withdraw
                  </button>
                )}
              </div>

              {activated && (
                <div style={{ marginTop: 12 }}>
                  <div style={{ background: "#f8f8f8", borderRadius: 10, padding: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <div>
                        <div style={{ fontSize: 11, color: "#888" }}>Balance</div>
                        <div style={{ fontSize: 20, fontWeight: 900, color: m.color }}>{formatNaira(balance)}</div>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 11, color: "#888" }}>Next profit in</div>
                        <div style={{ fontSize: 16, fontWeight: 700, color: "#333", fontFamily: "monospace" }}>{formatCountdown(timeLeft)}</div>
                      </div>
                    </div>
                  </div>

                  {showWithdraw && (
                    <div style={{ marginTop: 12, border: "1px solid #e0e0e0", borderRadius: 10, padding: 14 }}>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#333", marginBottom: 10 }}>Withdraw from {m.name}</div>
                      <div style={{ fontSize: 13, color: "#888", marginBottom: 12 }}>Min: {formatNaira(m.minWithdraw)} · Balance: {formatNaira(balance)}</div>
                      {["bankName", "accountNumber", "accountHolder", "amount"].map((k) => (
                        <input key={k} className="input-field" style={{ marginBottom: 8 }} placeholder={k === "bankName" ? "Bank Name" : k === "accountNumber" ? "Account Number" : k === "accountHolder" ? "Account Holder Name" : `Amount (Min: ₦${m.minWithdraw})`} value={(withdrawForm as any)[k]} onChange={(e) => setWithdrawForm({ ...withdrawForm, [k]: e.target.value })} type={k === "amount" ? "number" : "text"} />
                      ))}
                      <div style={{ display: "flex", gap: 8, marginTop: 4 }}>
                        <button onClick={() => setWithdrawing(null)} style={{ flex: 1, background: "#f0f0f0", color: "#555", border: "none", borderRadius: 8, padding: 10, cursor: "pointer", fontWeight: 600 }}>Cancel</button>
                        <button onClick={() => submitWithdrawal(m)} style={{ flex: 2, background: m.color, color: "white", border: "none", borderRadius: 8, padding: 10, cursor: "pointer", fontWeight: 700 }}>Submit</button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {!activated && (
                <button onClick={() => activateMachine(m)} disabled={loading === m.key} style={{ marginTop: 12, background: `linear-gradient(135deg,${m.color},${m.color}cc)`, color: "white", border: "none", borderRadius: 8, padding: "12px", width: "100%", cursor: "pointer", fontWeight: 700, fontSize: 15 }}>
                  {loading === m.key ? "Activating..." : `Activate for ${formatNaira(m.activation)}`}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
