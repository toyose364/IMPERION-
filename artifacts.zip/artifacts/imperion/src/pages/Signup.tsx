import React, { useState } from "react";
import { useLocation } from "wouter";
import { signUp } from "../lib/auth";
import { useUser } from "../context/UserContext";
import { WHATSAPP_LINK, WHATSAPP_GROUP_NEWS, WHATSAPP_GROUP_COMMUNITY } from "../lib/utils";

export default function Signup() {
  const [, navigate] = useLocation();
  const { setUser } = useUser();
  const [form, setForm] = useState({ username: "", mobile: "", email: "", password: "", referral: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [created, setCreated] = useState(false);
  const [createdUsername, setCreatedUsername] = useState("");

  const handle = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) =>
    setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!navigator.onLine) { setError("No internet connection. Please check your network."); return; }
    if (!form.username || !form.mobile || !form.email || !form.password) { setError("All fields are required"); return; }
    if (!/^\d{6}$/.test(form.password)) { setError("Password must be exactly 6 digits"); return; }
    if (form.username.length < 3) { setError("Username must be at least 3 characters"); return; }
    setLoading(true);
    try {
      const result = await signUp(form.username, form.mobile, form.email, form.password, form.referral);
      if (result.success && result.user) {
        setCreatedUsername(result.user.username);
        setUser(result.user);
        setCreated(true);
      } else {
        setError(result.error || "Sign up failed. Please try again.");
      }
    } catch (err: any) {
      setError("Something went wrong. Please check your connection and try again.");
    }
    setLoading(false);
  };

  /* ── Success Screen ── */
  if (created) {
    return (
      <div style={{ minHeight: "100vh", background: "#f8f8f8", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", padding: 24 }}>
        <div style={{ background: "white", borderRadius: 24, padding: 36, textAlign: "center", maxWidth: 380, width: "100%", boxShadow: "0 8px 40px rgba(192,0,0,0.12)" }}>
          {/* Animated tick */}
          <div style={{ width: 80, height: 80, background: "linear-gradient(135deg,#c00000,#e00000)", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", fontSize: 40 }}>
            ✅
          </div>
          <h2 style={{ fontSize: 24, fontWeight: 900, color: "#222", marginBottom: 8 }}>Account Created!</h2>
          <p style={{ fontSize: 16, color: "#555", marginBottom: 4 }}>Welcome to IMPERION,</p>
          <p style={{ fontSize: 22, fontWeight: 800, color: "#c00000", marginBottom: 20 }}>@{createdUsername}</p>
          <p style={{ fontSize: 14, color: "#888", marginBottom: 28, lineHeight: 1.6 }}>
            Your account has been created successfully. Deposit ₦1,000 to activate and start earning!
          </p>
          <button
            onClick={() => navigate("/dashboard")}
            className="btn-primary"
            style={{ fontSize: 17, padding: "14px" }}
          >
            Go to Dashboard 🚀
          </button>
        </div>

        {/* WhatsApp Groups */}
        <div style={{ background: "white", borderRadius: 16, padding: 20, marginTop: 20, border: "1px solid #f0e0e0", textAlign: "center", width: "100%", maxWidth: 380 }}>
          <p style={{ fontWeight: 700, color: "#333", marginBottom: 12 }}>Join Our WhatsApp Groups</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <a href={WHATSAPP_GROUP_NEWS} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>📢 IMPERION NEWS Group</a>
            <a href={WHATSAPP_GROUP_COMMUNITY} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>👥 Community Group</a>
          </div>
        </div>
      </div>
    );
  }

  /* ── Sign-up Form ── */
  return (
    <div style={{ minHeight: "100vh", background: "#f8f8f8", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "linear-gradient(135deg,#c00000,#e00000)", padding: "20px 24px", textAlign: "center" }}>
        <div style={{ color: "white", fontWeight: 900, fontSize: 28, letterSpacing: 3, marginBottom: 4 }}>IMPERION</div>
        <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 14 }}>Create Your Account</p>
      </div>

      <div style={{ padding: 24, maxWidth: 420, margin: "0 auto", width: "100%" }}>
        <div className="imperion-card" style={{ padding: 28 }}>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: "#333", marginBottom: 4 }}>Sign Up</h2>
          <p style={{ fontSize: 14, color: "#888", marginBottom: 24 }}>Start earning with IMPERION today</p>

          {error && (
            <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>
              {error}
            </div>
          )}

          <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="form-group">
              <label>Username</label>
              <input className="input-field" placeholder="Choose a unique username" value={form.username} onChange={handle("username")} />
            </div>
            <div className="form-group">
              <label>Mobile Number</label>
              <input className="input-field" placeholder="e.g. 08012345678" value={form.mobile} onChange={handle("mobile")} type="tel" />
            </div>
            <div className="form-group">
              <label>Email Address</label>
              <input className="input-field" placeholder="your@email.com" value={form.email} onChange={handle("email")} type="email" />
            </div>
            <div className="form-group">
              <label>6-Digit Password</label>
              <input className="input-field" placeholder="6 digits only (e.g. 123456)" value={form.password} onChange={handle("password")} type="password" maxLength={6} inputMode="numeric" pattern="\d{6}" />
              <span style={{ fontSize: 12, color: "#888" }}>Must be exactly 6 numbers</span>
            </div>
            <div className="form-group">
              <label>Referral Code (Optional)</label>
              <input className="input-field" placeholder="Enter referral code if you have one" value={form.referral} onChange={handle("referral")} />
            </div>
            <button className="btn-primary" type="submit" disabled={loading}>
              {loading ? "Creating Account..." : "Create Account"}
            </button>
          </form>

          <p style={{ textAlign: "center", marginTop: 16, fontSize: 14, color: "#666" }}>
            Already have an account?{" "}
            <span onClick={() => navigate("/login")} style={{ color: "#c00000", cursor: "pointer", fontWeight: 700 }}>Login</span>
          </p>
        </div>

        <div style={{ textAlign: "center", marginTop: 20 }}>
          <p style={{ fontSize: 13, color: "#666", marginBottom: 8 }}>Need help? Contact our support team</p>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn">
            <span>💬</span> Customer Care
          </a>
        </div>

        <div style={{ background: "white", borderRadius: 16, padding: 20, marginTop: 16, border: "1px solid #f0e0e0", textAlign: "center" }}>
          <p style={{ fontWeight: 700, color: "#333", marginBottom: 12 }}>Join Our WhatsApp Groups</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <a href={WHATSAPP_GROUP_NEWS} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>📢 IMPERION NEWS Group</a>
            <a href={WHATSAPP_GROUP_COMMUNITY} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>👥 Community Group</a>
          </div>
        </div>
      </div>
    </div>
  );
}
