import React, { useState } from "react";
import { useUser } from "../context/UserContext";
import { formatNaira } from "../lib/utils";
import { useLocation } from "wouter";

const ACTIVATION_COST = 1000;

export default function Subscription() {
  const { user, updateUserData } = useUser();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  const [, navigate] = useLocation();

  const activate = async () => {
    if (!user) return;
    setError(""); setSuccess(false);
    if (!navigator.onLine) { setError("No internet connection"); return; }
    if (user.isActivated) { setError("Account already activated"); return; }
    if ((user.depositBalance || 0) < ACTIVATION_COST) {
      setError(`Insufficient deposit balance. You need ${formatNaira(ACTIVATION_COST)} but have ${formatNaira(user.depositBalance || 0)}. Please deposit first.`);
      return;
    }
    setLoading(true);
    try {
      await updateUserData({
        isActivated: true,
        depositBalance: (user.depositBalance || 0) - ACTIVATION_COST,
      });
      setSuccess(true);
    } catch {
      setError("Activation failed. Try again.");
    }
    setLoading(false);
  };

  if (!user) return null;

  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>⚡</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Account Activation</div><div style={{ fontSize: 13, opacity: 0.85 }}>Unlock all IMPERION features</div></div>
      </div>

      <div style={{ padding: 24 }}>
        {user.isActivated ? (
          <div style={{ background: "linear-gradient(135deg,#155724,#28a745)", borderRadius: 24, padding: 40, textAlign: "center", color: "white" }}>
            <div style={{ fontSize: 60, marginBottom: 16 }}>✅</div>
            <div style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>Account Activated!</div>
            <div style={{ fontSize: 15, opacity: 0.85, marginBottom: 24 }}>You have full access to all IMPERION features</div>
            <button onClick={() => navigate("/dashboard")} style={{ background: "white", color: "#155724", border: "none", borderRadius: 12, padding: "14px 32px", fontSize: 16, fontWeight: 800, cursor: "pointer" }}>Go to Dashboard</button>
          </div>
        ) : (
          <>
            <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 24, padding: 32, textAlign: "center", color: "white", marginBottom: 20 }}>
              <div style={{ fontSize: 50, marginBottom: 12 }}>⚡</div>
              <div style={{ fontSize: 28, fontWeight: 900, marginBottom: 4 }}>Activate Your Account</div>
              <div style={{ fontSize: 40, fontWeight: 900, color: "#FFD700", marginBottom: 8 }}>{formatNaira(ACTIVATION_COST)}</div>
              <div style={{ fontSize: 14, opacity: 0.85 }}>One-time activation fee</div>
            </div>

            <div style={{ background: "white", borderRadius: 16, padding: 20, border: "1px solid #f0e0e0", marginBottom: 16 }}>
              <h3 style={{ fontSize: 16, fontWeight: 700, color: "#333", marginBottom: 12 }}>What you unlock:</h3>
              {[
                "✅ Complete tasks and earn money",
                "👥 Invite friends and earn referral bonuses",
                "🎁 Claim daily ₦100 bonus",
                "📈 Access investment machines",
                "📱 Purchase airtime/data",
                "💳 Withdraw your earnings",
              ].map((f, i) => (
                <div key={i} style={{ fontSize: 14, color: "#555", marginBottom: 8, lineHeight: 1.5 }}>{f}</div>
              ))}
            </div>

            <div style={{ background: "#fff8f0", borderRadius: 12, padding: 16, border: "1px solid #ffd9b3", marginBottom: 16 }}>
              <div style={{ fontSize: 14, color: "#555" }}>
                <strong>Your Deposit Balance:</strong> <span style={{ color: "#c00000", fontWeight: 700 }}>{formatNaira(user.depositBalance || 0)}</span>
              </div>
              <div style={{ fontSize: 13, color: "#888", marginTop: 4 }}>
                ₦{ACTIVATION_COST} will be deducted from your deposit balance
              </div>
            </div>

            {error && <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>{error}</div>}
            {success && <div style={{ background: "#d4edda", border: "1px solid #c3e6cb", borderRadius: 8, padding: "10px 14px", color: "#155724", fontSize: 14, marginBottom: 16 }}>✅ Account activated successfully!</div>}

            {(user.depositBalance || 0) < ACTIVATION_COST ? (
              <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ background: "#fff3cd", borderRadius: 8, padding: "12px", color: "#856404", textAlign: "center", fontWeight: 600 }}>
                  You need to deposit ₦{ACTIVATION_COST} first
                </div>
                <button onClick={() => navigate("/deposit")} className="btn-primary">Go to Deposit</button>
              </div>
            ) : (
              <button className="btn-primary" onClick={activate} disabled={loading} style={{ fontSize: 18, padding: "16px" }}>
                {loading ? "Activating..." : `Activate for ${formatNaira(ACTIVATION_COST)}`}
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
