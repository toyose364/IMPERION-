import React from "react";
import { WHATSAPP_LINK } from "../lib/utils";

export default function PlaceAds() {
  return (
    <div>
      <div className="page-header">
        <span style={{ fontSize: 22 }}>📢</span>
        <div><div style={{ fontWeight: 800, fontSize: 18 }}>Place Ads</div><div style={{ fontSize: 13, opacity: 0.85 }}>Advertise to our community</div></div>
      </div>

      <div style={{ padding: 24, textAlign: "center" }}>
        <div style={{ background: "linear-gradient(135deg,#c00000,#ff4444)", borderRadius: 24, padding: 40, color: "white", marginBottom: 24 }}>
          <div style={{ fontSize: 60, marginBottom: 16 }}>📢</div>
          <h2 style={{ fontSize: 26, fontWeight: 900, marginBottom: 12 }}>Advertise on IMPERION</h2>
          <p style={{ fontSize: 15, opacity: 0.9, lineHeight: 1.6, marginBottom: 24 }}>
            Reach thousands of active Nigerian users with your ads. Contact our admin on WhatsApp to get started.
          </p>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#25D366", color: "white", padding: "16px 32px", borderRadius: 16, textDecoration: "none", fontWeight: 800, fontSize: 18 }}>
            💬 Contact Admin on WhatsApp
          </a>
        </div>

        <div style={{ background: "white", borderRadius: 16, padding: 24, border: "1px solid #f0e0e0" }}>
          <h3 style={{ fontSize: 18, fontWeight: 700, color: "#333", marginBottom: 16 }}>Why Advertise with Us?</h3>
          {[
            "📊 10,000+ active Nigerian users",
            "📱 Mobile-first platform",
            "🎯 Targeted Nigerian audience",
            "💰 Affordable ad rates",
            "⚡ Quick ad setup",
          ].map((f, i) => (
            <div key={i} style={{ fontSize: 15, color: "#555", marginBottom: 10, textAlign: "left", padding: "8px 0", borderBottom: "1px solid #f0f0f0" }}>{f}</div>
          ))}
          <a href="https://wa.me/2347084318814?text=Hi%20I%20want%20to%20place%20an%20ad%20on%20IMPERION" target="_blank" rel="noreferrer" style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 8, background: "#25D366", color: "white", padding: "14px", borderRadius: 12, textDecoration: "none", fontWeight: 700, fontSize: 16, marginTop: 16 }}>
            💬 +234 7084318814
          </a>
        </div>
      </div>
    </div>
  );
}
