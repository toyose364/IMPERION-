import React, { useState } from "react";
import { useLocation } from "wouter";
import { login } from "../lib/auth";
import { useUser } from "../context/UserContext";
import { WHATSAPP_LINK, WHATSAPP_GROUP_NEWS, WHATSAPP_GROUP_COMMUNITY } from "../lib/utils";

export default function Login() {
  const [, navigate] = useLocation();
  const { setUser } = useUser();
  const [form, setForm] = useState({ email: "", password: "" });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handle = (k: string) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    if (!navigator.onLine) { setError("No internet connection. Please check your network."); return; }
    if (!form.email || !form.password) { setError("All fields are required"); return; }
    setLoading(true);
    const result = await login(form.email, form.password);
    if (result.success && result.user) {
      setUser(result.user);
      navigate("/dashboard");
    } else {
      setError(result.error || "Login failed");
    }
    setLoading(false);
  };

  return (
    <div style={{ minHeight: "100vh", background: "#f8f8f8", display: "flex", flexDirection: "column" }}>
      <div style={{ background: "linear-gradient(135deg,#c00000,#e00000)", padding: "20px 24px", textAlign: "center" }}>
        <div style={{ color: "white", fontWeight: 900, fontSize: 28, letterSpacing: 3, marginBottom: 4 }}>IMPERION</div>
        <p style={{ color: "rgba(255,255,255,0.85)", fontSize: 14 }}>Welcome Back!</p>
      </div>

      <div style={{ padding: 24, maxWidth: 420, margin: "0 auto", width: "100%" }}>
        <div className="imperion-card" style={{ padding: 28 }}>
          <h2 style={{ fontSize: 22, fontWeight: 800, color: "#333", marginBottom: 4 }}>Login</h2>
          <p style={{ fontSize: 14, color: "#888", marginBottom: 24 }}>Sign in to your IMPERION account</p>

          {error && (
            <div style={{ background: "#fee", border: "1px solid #fcc", borderRadius: 8, padding: "10px 14px", color: "#c00000", fontSize: 14, marginBottom: 16 }}>
              {error}
            </div>
          )}

          <form onSubmit={submit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            <div className="form-group">
              <label>Email Address</label>
              <input className="input-field" placeholder="your@email.com" value={form.email} onChange={handle("email")} type="email" />
            </div>
            <div className="form-group">
              <label>6-Digit Password</label>
              <input className="input-field" placeholder="Enter your 6-digit password" value={form.password} onChange={handle("password")} type="password" maxLength={6} inputMode="numeric" />
            </div>
            <button className="btn-primary" type="submit" disabled={loading}>
              {loading ? "Logging in..." : "Login"}
            </button>
          </form>

          <p style={{ textAlign: "center", marginTop: 16, fontSize: 14, color: "#666" }}>
            Don't have an account?{" "}
            <span onClick={() => navigate("/signup")} style={{ color: "#c00000", cursor: "pointer", fontWeight: 700 }}>Sign Up</span>
          </p>

          <p style={{ textAlign: "center", marginTop: 8, fontSize: 13, color: "#888", cursor: "pointer" }} onClick={() => navigate("/")}>
            ← Back to Home
          </p>
        </div>

        <div style={{ textAlign: "center", marginTop: 20 }}>
          <p style={{ fontSize: 13, color: "#666", marginBottom: 8 }}>Need help? Contact our support team</p>
          <a href={WHATSAPP_LINK} target="_blank" rel="noreferrer" className="whatsapp-btn">
            <span>💬</span> Customer Care
          </a>
        </div>

        <div style={{ background: "white", borderRadius: 16, padding: 20, marginTop: 16, border: "1px solid #f0e0e0", textAlign: "center" }}>
          <p style={{ fontWeight: 700, color: "#333", marginBottom: 12 }}>Join Our WhatsApp Groups</p>
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            <a href={WHATSAPP_GROUP_NEWS} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>📢 IMPERION NEWS Group</a>
            <a href={WHATSAPP_GROUP_COMMUNITY} target="_blank" rel="noreferrer" className="whatsapp-btn" style={{ justifyContent: "center" }}>👥 Community Group</a>
          </div>
        </div>
      </div>
    </div>
  );
}
