import React, { createContext, useContext, useState, useEffect, useCallback } from "react";
import { User, getUser, updateUser } from "../lib/auth";
import { saveSession, loadSession, clearSession } from "../lib/store";

interface UserContextType {
  user: User | null;
  loading: boolean;
  setUser: (u: User | null) => void;
  refreshUser: () => Promise<void>;
  logout: () => void;
  updateUserData: (data: Partial<User>) => Promise<void>;
}

const UserContext = createContext<UserContextType>({
  user: null,
  loading: true,
  setUser: () => {},
  refreshUser: async () => {},
  logout: () => {},
  updateUserData: async () => {},
});

export function UserProvider({ children }: { children: React.ReactNode }) {
  const [user, setUserState] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const session = loadSession();
    if (session) {
      // Immediately restore session from localStorage so the user is never left hanging
      setUserState(session);
      setLoading(false);

      // Then try to refresh from Firestore in the background
      getUser(session.uid).then((freshUser) => {
        if (freshUser) {
          // Got fresh data — update state and save
          setUserState(freshUser);
          saveSession(freshUser);
        }
        // If freshUser is null (network issue / Firestore unreachable),
        // keep the cached session — do NOT clear it.
        // The user will stay logged in with their last-known data.
      }).catch(() => {
        // Firestore failed — still keep the cached session
      });
    } else {
      setLoading(false);
    }
  }, []);

  const setUser = useCallback((u: User | null) => {
    setUserState(u);
    if (u) saveSession(u);
    else clearSession();
  }, []);

  const refreshUser = useCallback(async () => {
    if (!user) return;
    try {
      const fresh = await getUser(user.uid);
      if (fresh) {
        setUserState(fresh);
        saveSession(fresh);
      }
    } catch {
      // keep current state on failure
    }
  }, [user]);

  const logout = useCallback(() => {
    clearSession();
    setUserState(null);
  }, []);

  const updateUserData = useCallback(async (data: Partial<User>) => {
    if (!user) return;
    await updateUser(user.uid, data);
    const updated = { ...user, ...data };
    setUserState(updated);
    saveSession(updated);
  }, [user]);

  return (
    <UserContext.Provider value={{ user, loading, setUser, refreshUser, logout, updateUserData }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  return useContext(UserContext);
}
